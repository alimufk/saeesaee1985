'use client';

import { useState, useEffect } from 'react';
import { 
  Search, Heart, Download, Share2, X, ZoomIn, ZoomOut, 
  Grid3x3, Moon, BookOpen, Star, Calendar, Box, Landmark,
  ChevronLeft, TrendingUp, Clock, Eye, Check
} from 'lucide-react';
import { wallpapers, categories, Wallpaper, getWallpapersByCategory, searchWallpapers, getMostDownloaded, getNewest } from '@/data/wallpapers';
import * as LucideIcons from 'lucide-react';

export default function WallpapersPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'newest' | 'popular'>('newest');
  const [selectedWallpaper, setSelectedWallpaper] = useState<Wallpaper | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [zoom, setZoom] = useState(1);
  const [downloading, setDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('noor-wallpaper-favorites');
    if (saved) setFavorites(JSON.parse(saved));
  }, []);

  const toggleFavorite = (id: string) => {
    const newFavs = favorites.includes(id) 
      ? favorites.filter(f => f !== id) 
      : [...favorites, id];
    setFavorites(newFavs);
    localStorage.setItem('noor-wallpaper-favorites', JSON.stringify(newFavs));
  };

  const handleDownload = async (wallpaper: Wallpaper) => {
    setDownloading(true);
    setDownloaded(false);
    
    try {
      const response = await fetch(wallpaper.image);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${wallpaper.titleAr}.jpg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      setDownloaded(true);
      setTimeout(() => setDownloaded(false), 2000);
    } catch (error) {
      console.error('Download failed:', error);
      // Fallback: فتح الصورة في نافذة جديدة
      window.open(wallpaper.image, '_blank');
    } finally {
      setDownloading(false);
    }
  };

  const handleShare = async (wallpaper: Wallpaper) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: wallpaper.titleAr,
          text: `خلفية إسلامية: ${wallpaper.titleAr}`,
          url: wallpaper.image,
        });
      } catch (error) {
        console.log('Share cancelled');
      }
    } else {
      // Fallback: نسخ الرابط
      navigator.clipboard?.writeText(wallpaper.image);
      alert('تم نسخ رابط الصورة');
    }
  };

  const zoomIn = () => setZoom(Math.min(zoom + 0.5, 3));
  const zoomOut = () => setZoom(Math.max(zoom - 0.5, 0.5));
  const resetZoom = () => setZoom(1);

  // فلترة وترتيب الخلفيات
  let filteredWallpapers = searchQuery 
    ? searchWallpapers(searchQuery)
    : getWallpapersByCategory(selectedCategory);

  if (sortBy === 'popular') {
    filteredWallpapers = filteredWallpapers.sort((a, b) => b.downloads - a.downloads);
  } else {
    filteredWallpapers = filteredWallpapers.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  // Modal عرض الخلفية
  if (selectedWallpaper) {
    return (
      <div className="fixed inset-0 z-50 bg-black flex flex-col max-w-[480px] mx-auto">
        {/* Header */}
        <div className="glass border-b border-white/10 p-4 flex items-center justify-between z-10">
          <button 
            onClick={() => { setSelectedWallpaper(null); resetZoom(); }}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white"
          >
            <ChevronLeft className="w-5 h-5 rotate-180" />
          </button>
          <div className="text-center text-white">
            <p className="font-bold text-sm">{selectedWallpaper.titleAr}</p>
            <p className="text-xs opacity-70">{selectedWallpaper.resolution}</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => toggleFavorite(selectedWallpaper.id)}
              className={`p-2 rounded-full ${favorites.includes(selectedWallpaper.id) ? 'bg-rose-500 text-white' : 'bg-white/10 hover:bg-white/20 text-white'}`}
            >
              <Heart className={`w-5 h-5 ${favorites.includes(selectedWallpaper.id) ? 'fill-current' : ''}`} />
            </button>
          </div>
        </div>

        {/* Image */}
        <div className="flex-1 flex items-center justify-center overflow-hidden bg-black/90">
          <img
            src={selectedWallpaper.image}
            alt={selectedWallpaper.titleAr}
            className="max-w-full max-h-full object-contain transition-transform duration-300"
            style={{ transform: `scale(${zoom})` }}
          />
        </div>

        {/* Zoom Controls */}
        <div className="glass border-t border-white/10 p-3 flex items-center justify-center gap-3 z-10">
          <button
            onClick={zoomOut}
            disabled={zoom <= 0.5}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white disabled:opacity-30"
          >
            <ZoomOut className="w-5 h-5" />
          </button>
          <span className="text-white text-sm font-medium min-w-[60px] text-center">
            {Math.round(zoom * 100)}%
          </span>
          <button
            onClick={zoomIn}
            disabled={zoom >= 3}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white disabled:opacity-30"
          >
            <ZoomIn className="w-5 h-5" />
          </button>
          <button
            onClick={resetZoom}
            className="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white text-xs"
          >
            إعادة تعيين
          </button>
        </div>

        {/* Action Buttons */}
        <div className="glass border-t border-white/10 p-4 grid grid-cols-3 gap-2 z-10">
          <button
            onClick={() => handleDownload(selectedWallpaper)}
            disabled={downloading}
            className="flex flex-col items-center gap-1 p-3 rounded-xl bg-[var(--color-primary)] text-white hover:bg-[var(--color-primary-dark)] transition-colors disabled:opacity-50"
          >
            {downloaded ? (
              <>
                <Check className="w-5 h-5" />
                <span className="text-xs">تم</span>
              </>
            ) : downloading ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span className="text-xs">جارٍ...</span>
              </>
            ) : (
              <>
                <Download className="w-5 h-5" />
                <span className="text-xs">تحميل</span>
              </>
            )}
          </button>
          <button
            onClick={() => handleShare(selectedWallpaper)}
            className="flex flex-col items-center gap-1 p-3 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <Share2 className="w-5 h-5" />
            <span className="text-xs">مشاركة</span>
          </button>
          <button
            onClick={() => toggleFavorite(selectedWallpaper.id)}
            className={`flex flex-col items-center gap-1 p-3 rounded-xl transition-colors ${
              favorites.includes(selectedWallpaper.id) 
                ? 'bg-rose-500 text-white' 
                : 'bg-white/10 hover:bg-white/20 text-white'
            }`}
          >
            <Heart className={`w-5 h-5 ${favorites.includes(selectedWallpaper.id) ? 'fill-current' : ''}`} />
            <span className="text-xs">مفضلة</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div className="bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] rounded-3xl p-6 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
        <div className="relative">
          <h2 className="font-display text-2xl font-bold mb-2">الخلفيات الإسلامية</h2>
          <p className="opacity-90 text-sm mb-4">خلفيات فاخرة بجودة عالية</p>
          <div className="flex gap-3">
            <div className="bg-white/15 rounded-xl px-3 py-2">
              <p className="text-xs opacity-80">الخلفيات</p>
              <p className="font-bold">{wallpapers.length}</p>
            </div>
            <div className="bg-white/15 rounded-xl px-3 py-2">
              <p className="text-xs opacity-80">التصنيفات</p>
              <p className="font-bold">{categories.length - 1}</p>
            </div>
            <div className="bg-white/15 rounded-xl px-3 py-2">
              <p className="text-xs opacity-80">الجودة</p>
              <p className="font-bold">4K</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--color-text-subtle)]" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="ابحث عن خلفية..."
          className="w-full bg-[var(--color-bg-elevated)] border border-[var(--color-border)] rounded-2xl py-3 pr-10 pl-4 text-sm focus:outline-none focus:border-[var(--color-primary)]"
        />
      </div>

      {/* Sort & Filter */}
      <div className="flex gap-2">
        <button
          onClick={() => setSortBy('newest')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-xl text-sm font-medium transition-all ${
            sortBy === 'newest' 
              ? 'bg-[var(--color-primary)] text-white shadow-lg' 
              : 'bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]'
          }`}
        >
          <Clock className="w-4 h-4" />
          الأحدث
        </button>
        <button
          onClick={() => setSortBy('popular')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-xl text-sm font-medium transition-all ${
            sortBy === 'popular' 
              ? 'bg-[var(--color-primary)] text-white shadow-lg' 
              : 'bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          الأكثر تحميلاً
        </button>
      </div>

      {/* Categories */}
      <div className="overflow-x-auto no-scrollbar">
        <div className="flex gap-2 pb-2">
          {categories.map((cat) => {
            const Icon = (LucideIcons as any)[cat.icon] || Grid3x3;
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => { setSelectedCategory(cat.id); setSearchQuery(''); }}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl whitespace-nowrap text-sm font-medium transition-all ${
                  isActive 
                    ? 'bg-[var(--color-primary)] text-white shadow-lg' 
                    : 'bg-[var(--color-bg-elevated)] border border-[var(--color-border)] hover:border-[var(--color-primary)]'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{cat.name}</span>
                <span className={`text-xs ${isActive ? 'opacity-80' : 'text-[var(--color-text-subtle)]'}`}>
                  {cat.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 gap-3">
        {filteredWallpapers.map((wallpaper) => (
          <WallpaperCard
            key={wallpaper.id}
            wallpaper={wallpaper}
            isFavorite={favorites.includes(wallpaper.id)}
            onSelect={() => setSelectedWallpaper(wallpaper)}
            onToggleFavorite={() => toggleFavorite(wallpaper.id)}
          />
        ))}
      </div>

      {filteredWallpapers.length === 0 && (
        <div className="text-center py-12 text-[var(--color-text-muted)]">
          <Grid3x3 className="w-12 h-12 mx-auto mb-3 opacity-40" />
          <p className="font-bold mb-1">لا توجد خلفيات</p>
          <p className="text-sm">جرب البحث بكلمات أخرى أو اختر تصنيف مختلف</p>
        </div>
      )}
    </div>
  );
}

function WallpaperCard({
  wallpaper,
  isFavorite,
  onSelect,
  onToggleFavorite,
}: {
  wallpaper: Wallpaper;
  isFavorite: boolean;
  onSelect: () => void;
  onToggleFavorite: () => void;
}) {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className="group relative rounded-2xl overflow-hidden bg-[var(--color-bg-elevated)] border border-[var(--color-border)] card-hover">
      <button onClick={onSelect} className="w-full">
        <div className="relative aspect-[3/4] bg-[var(--color-surface)]">
          {!loaded && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-8 h-8 border-3 border-[var(--color-primary)] border-t-transparent rounded-full animate-spin" />
            </div>
          )}
          <img
            src={wallpaper.thumbnail}
            alt={wallpaper.titleAr}
            onLoad={() => setLoaded(true)}
            className={`w-full h-full object-cover transition-all duration-300 group-hover:scale-110 ${loaded ? 'opacity-100' : 'opacity-0'}`}
          />
          
          {/* Overlay on hover */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          
          {/* Resolution Badge */}
          <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
            {wallpaper.resolution}
          </div>

          {/* Downloads Badge */}
          <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-sm text-white text-[10px] px-2 py-0.5 rounded-full flex items-center gap-1">
            <Eye className="w-3 h-3" />
            {wallpaper.downloads.toLocaleString('ar-EG')}
          </div>
        </div>
      </button>

      {/* Info & Actions */}
      <div className="p-3">
        <p className="font-bold text-sm mb-1 truncate">{wallpaper.titleAr}</p>
        <p className="text-xs text-[var(--color-text-muted)] mb-2">{wallpaper.categoryAr}</p>
        
        <div className="flex items-center justify-between">
          <button
            onClick={(e) => { e.stopPropagation(); onToggleFavorite(); }}
            className={`p-1.5 rounded-full transition-colors ${
              isFavorite ? 'text-rose-500 bg-rose-500/10' : 'text-[var(--color-text-subtle)] hover:bg-[var(--color-surface)]'
            }`}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
          </button>
          <span className="text-xs text-[var(--color-text-subtle)] flex items-center gap-1">
            <Download className="w-3 h-3" />
            {wallpaper.downloads.toLocaleString('ar-EG')}
          </span>
        </div>
      </div>
    </div>
  );
}
