'use client';

import { useState, useEffect } from 'react';
import { 
  Moon, Sun, BookOpen, Heart, Calendar, Sparkles, Star,
  TrendingUp, Clock, Users, Gift, ChevronLeft, Volume2,
  Target, Flame, Droplets, Coffee
} from 'lucide-react';
import { 
  ramadanInfo, ramadanDuas, ramadanTips, lastTenDays, 
  ramadanVirtues, zakatAlFitr, quranKhatmGoals
} from '@/data/ramadan';

export default function RamadanPage() {
  const [tab, setTab] = useState<'countdown' | 'duas' | 'tips' | 'qadr' | 'tracker'>('countdown');
  const [fastingDays, setFastingDays] = useState<number[]>([]);
  const [selectedGoal, setSelectedGoal] = useState(quranKhatmGoals[0]);
  const [currentJuz, setCurrentJuz] = useState(1);

  useEffect(() => {
    const saved = localStorage.getItem('noor-fasting-tracker');
    if (saved) setFastingDays(JSON.parse(saved));
    const savedJuz = localStorage.getItem('noor-quran-progress');
    if (savedJuz) setCurrentJuz(parseInt(savedJuz));
  }, []);

  const toggleFastingDay = (day: number) => {
    const newDays = fastingDays.includes(day)
      ? fastingDays.filter(d => d !== day)
      : [...fastingDays, day];
    setFastingDays(newDays);
    localStorage.setItem('noor-fasting-tracker', JSON.stringify(newDays));
  };

  const updateJuzProgress = (juz: number) => {
    setCurrentJuz(juz);
    localStorage.setItem('noor-quran-progress', juz.toString());
  };

  const getCountdown = () => {
    const now = new Date();
    const ramadanStart = new Date(ramadanInfo.startDate);
    const ramadanEnd = new Date(ramadanInfo.endDate);
    
    if (now < ramadanStart) {
      const diff = ramadanStart.getTime() - now.getTime();
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      return { text: `متبقي ${days} يوم على رمضان`, type: 'before' };
    } else if (now > ramadanEnd) {
      return { text: 'انتهى رمضان', type: 'after' };
    } else {
      const day = Math.floor((now.getTime() - ramadanStart.getTime()) / (1000 * 60 * 60 * 24)) + 1;
      return { text: `اليوم ${day} من رمضان`, type: 'during' };
    }
  };

  const countdown = getCountdown();

  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div className="bg-gradient-to-br from-purple-600 via-indigo-600 to-purple-700 rounded-3xl p-6 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <Moon className="w-6 h-6" />
            <h2 className="font-display text-2xl font-bold">رمضان وصائمون</h2>
          </div>
          <p className="opacity-90 text-sm mb-4">شهر الرحمة والمغفرة والعتق من النار</p>
          
          {/* Countdown */}
          <div className="bg-white/15 rounded-2xl p-4 backdrop-blur-sm">
            <div className="text-center">
              <p className="text-sm opacity-90 mb-1">{ramadanInfo.gregorianYear} / {ramadanInfo.year} هـ</p>
              <p className="text-3xl font-bold font-display mb-2">{countdown.text}</p>
              {countdown.type === 'during' && (
                <div className="flex items-center justify-center gap-2 text-sm">
                  <Clock className="w-4 h-4" />
                  <span>السحور: 04:45</span>
                  <span>•</span>
                  <span>الإفطار: 18:15</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
        {[
          { id: 'countdown', label: 'العد التنازلي', icon: Clock },
          { id: 'duas', label: 'الأدعية', icon: Heart },
          { id: 'tips', label: 'نصائح', icon: Sparkles },
          { id: 'qadr', label: 'ليلة القدر', icon: Star },
          { id: 'tracker', label: 'المتابعة', icon: Target },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id as any)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl whitespace-nowrap text-sm font-medium transition-all ${
              tab === t.id 
                ? 'bg-[var(--color-primary)] text-white shadow-lg' 
                : 'bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]'
            }`}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      {tab === 'countdown' && (
        <div className="space-y-4">
          {/* Virtues */}
          <div>
            <h3 className="font-display font-bold text-lg mb-3 px-1">✨ فضائل رمضان</h3>
            <div className="grid grid-cols-2 gap-3">
              {ramadanVirtues.map((virtue, idx) => (
                <div key={idx} className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)]">
                  <div className="text-4xl mb-2">{virtue.icon}</div>
                  <h4 className="font-bold mb-1">{virtue.title}</h4>
                  <p className="text-xs text-[var(--color-text-muted)]">{virtue.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Zakat Al-Fitr */}
          <div className="bg-[var(--color-accent-light)] border border-[var(--color-accent)] rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 rounded-xl bg-[var(--color-accent)] flex items-center justify-center text-white">
                <Gift className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold">زكاة الفطر</h4>
                <p className="text-xs text-[var(--color-text-muted)]">واجبة على كل مسلم</p>
              </div>
            </div>
            <div className="space-y-2 text-sm">
              <p><span className="font-bold">المقدار:</span> {zakatAlFitr.amount} صاع ≈ {zakatAlFitr.kg} كجم</p>
              <p><span className="font-bold">الأنواع:</span> {zakatAlFitr.types.join('، ')}</p>
              <p><span className="font-bold">لكل شخص:</span> {zakatAlFitr.perPerson}</p>
            </div>
          </div>
        </div>
      )}

      {tab === 'duas' && (
        <div className="space-y-3">
          {ramadanDuas.map((dua) => (
            <div key={dua.id} className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)]">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h4 className="font-bold mb-1">{dua.title}</h4>
                  <p className="text-xs text-[var(--color-primary)]">{dua.when}</p>
                </div>
                <button className="p-2 rounded-full hover:bg-[var(--color-surface)]">
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
              <p className="font-quran text-lg leading-loose mb-3">{dua.text}</p>
              {dua.virtue && (
                <div className="bg-[var(--color-accent-light)] rounded-xl p-2 text-xs">
                  <span className="font-bold text-[var(--color-accent)]">الفضل: </span>
                  {dua.virtue}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {tab === 'tips' && (
        <div className="space-y-3">
          {ramadanTips.map((tip) => {
            const colors = {
              worship: 'from-emerald-500 to-teal-600',
              health: 'from-blue-500 to-cyan-600',
              food: 'from-orange-500 to-red-600',
              spiritual: 'from-purple-500 to-pink-600',
            };
            const icons = {
              worship: '🕌',
              health: '💪',
              food: '🍽️',
              spiritual: '❤️',
            };
            return (
              <div key={tip.id} className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)]">
                <div className="flex items-start gap-3">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${colors[tip.category]} flex items-center justify-center text-2xl shadow-lg`}>
                    {icons[tip.category]}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold mb-1">{tip.title}</h4>
                    <p className="text-sm text-[var(--color-text-muted)]">{tip.description}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {tab === 'qadr' && (
        <div className="space-y-4">
          {/* Last Ten Days */}
          <div>
            <h3 className="font-display font-bold text-lg mb-3 px-1">🌟 العشر الأواخر</h3>
            <div className="space-y-2">
              {lastTenDays.map((day) => (
                <div key={day.day} className="bg-gradient-to-br from-purple-600/10 to-indigo-600/10 rounded-2xl p-4 border border-purple-500/20">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center text-white font-bold">
                        {day.day}
                      </div>
                      <h4 className="font-bold">{day.title}</h4>
                    </div>
                    {day.day === 27 && (
                      <span className="text-xs bg-purple-600 text-white px-2 py-1 rounded-full">
                        ليلة القدر
                      </span>
                    )}
                  </div>
                  <div className="space-y-1">
                    {day.actions.map((action, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm">
                        <div className="w-1.5 h-1.5 rounded-full bg-purple-600" />
                        <span>{action}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Laylatul Qadr Dua */}
          <div className="bg-gradient-to-br from-yellow-500 to-amber-600 rounded-2xl p-6 text-white">
            <div className="flex items-center gap-2 mb-3">
              <Star className="w-6 h-6" />
              <h3 className="font-display text-xl font-bold">دعاء ليلة القدر</h3>
            </div>
            <p className="font-quran text-2xl leading-loose mb-3">
              اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي
            </p>
            <p className="text-sm opacity-90">
              قال النبي (ص): "من قام ليلة القدر إيماناً واحتساباً غُفر له ما تقدم من ذنبه"
            </p>
          </div>
        </div>
      )}

      {tab === 'tracker' && (
        <div className="space-y-4">
          {/* Fasting Tracker */}
          <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)]">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-bold">🌙 متتبع الصيام</h3>
              <div className="text-sm">
                <span className="font-bold text-[var(--color-primary)]">{fastingDays.length}</span>
                <span className="text-[var(--color-text-muted)]"> / 30 يوم</span>
              </div>
            </div>
            <div className="grid grid-cols-6 gap-2">
              {Array.from({ length: 30 }, (_, i) => i + 1).map((day) => (
                <button
                  key={day}
                  onClick={() => toggleFastingDay(day)}
                  className={`aspect-square rounded-lg flex items-center justify-center font-bold transition-all ${
                    fastingDays.includes(day)
                      ? 'bg-[var(--color-primary)] text-white shadow-lg'
                      : 'bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]'
                  }`}
                >
                  {day}
                </button>
              ))}
            </div>
            <div className="mt-4 h-2 bg-[var(--color-surface)] rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-l from-[var(--color-primary)] to-[var(--color-accent)] transition-all duration-500"
                style={{ width: `${(fastingDays.length / 30) * 100}%` }}
              />
            </div>
          </div>

          {/* Quran Progress */}
          <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)]">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-bold">📖 ختم القرآن</h3>
              <div className="text-sm">
                <span className="font-bold text-[var(--color-primary)]">{currentJuz}</span>
                <span className="text-[var(--color-text-muted)]"> / 30 جزء</span>
              </div>
            </div>
            
            {/* Goal Selector */}
            <div className="grid grid-cols-3 gap-2 mb-4">
              {quranKhatmGoals.map((goal, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedGoal(goal)}
                  className={`p-3 rounded-xl text-center transition-all ${
                    selectedGoal === goal
                      ? 'bg-[var(--color-primary)] text-white shadow-lg'
                      : 'bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]'
                  }`}
                >
                  <p className="font-bold text-sm">{goal.days} يوم</p>
                  <p className="text-xs opacity-80">{goal.description}</p>
                </button>
              ))}
            </div>

            {/* Progress Grid */}
            <div className="grid grid-cols-6 gap-2">
              {Array.from({ length: 30 }, (_, i) => i + 1).map((juz) => (
                <button
                  key={juz}
                  onClick={() => updateJuzProgress(juz)}
                  className={`aspect-square rounded-lg flex items-center justify-center text-xs font-bold transition-all ${
                    juz <= currentJuz
                      ? 'bg-[var(--color-primary)] text-white shadow-lg'
                      : 'bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]'
                  }`}
                >
                  {juz}
                </button>
              ))}
            </div>

            <div className="mt-4 h-2 bg-[var(--color-surface)] rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-l from-[var(--color-primary)] to-[var(--color-accent)] transition-all duration-500"
                style={{ width: `${(currentJuz / 30) * 100}%` }}
              />
            </div>

            <div className="mt-3 text-center text-sm text-[var(--color-text-muted)]">
              <p>الهدف: {selectedGoal.pagesPerDay} صفحة يومياً</p>
              <p className="text-xs">الجزء اليومي: {selectedGoal.juzPerDay}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
