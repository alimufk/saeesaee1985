'use client';

import { useState } from 'react';
import { Radio, Play, Pause, Volume2, Maximize2, Signal, ExternalLink, X } from 'lucide-react';

interface Stream {
  id: string;
  title: string;
  subtitle: string;
  thumbnail: string;
  location: string;
  viewers: number;
  live: boolean;
  youtubeVideo?: string;
  youtubeUrl?: string;
  websiteUrl?: string;
  type: 'video' | 'audio' | 'website';
}

const streams: Stream[] = [
  {
    id: 'mecca',
    title: 'المسجد الحرام - مكة المكرمة',
    subtitle: 'بث مباشر على مدار الساعة',
    thumbnail: '🕋',
    location: 'مكة المكرمة، السعودية',
    viewers: 12453,
    live: true,
    youtubeVideo: 'DhabgVBbksI',
    youtubeUrl: 'https://www.youtube.com/embed/live_stream?channel=UC2wXpWj0wNiJQ',
    type: 'video',
  },
  {
    id: 'medina',
    title: 'المسجد النبوي - المدينة المنورة',
    subtitle: 'الروضة الشريفة',
    thumbnail: '🕌',
    location: 'المدينة المنورة، السعودية',
    viewers: 8921,
    live: true,
    youtubeVideo: '6lHTb3wO9xg',
    youtubeUrl: 'https://www.youtube.com/embed/live_stream?channel=UC2wXpWj0wNiJQ',
    type: 'video',
  },
  {
    id: 'imam_ali',
    title: 'العتبة العلوية المقدسة',
    subtitle: 'مرقد الإمام علي (ع)',
    thumbnail: '⭐',
    location: 'النجف الأشرف، العراق',
    viewers: 5432,
    live: true,
    websiteUrl: 'https://imamali.net',
    type: 'website',
  },
  {
    id: 'imam_hussein',
    title: 'العتبة الحسينية المقدسة',
    subtitle: 'مرقد الإمام الحسين (ع)',
    thumbnail: '🌹',
    location: 'كربلاء المقدسة، العراق',
    viewers: 7821,
    live: true,
    websiteUrl: 'https://imamhussain.org/arabic',
    type: 'website',
  },
  {
    id: 'abbas',
    title: 'العتبة العباسية المقدسة',
    subtitle: 'مرقد أبي الفضل العباس (ع)',
    thumbnail: '☪',
    location: 'كربلاء المقدسة، العراق',
    viewers: 4321,
    live: true,
    websiteUrl: 'https://alkafeel.net',
    type: 'website',
  },
  {
    id: 'aljawadain',
    title: 'العتبتان المقدستان',
    subtitle: 'مرقد الإمام الجواد والإمام الكاظم (ع)',
    thumbnail: '🌟',
    location: 'الكاظمية، العراق',
    viewers: 2987,
    live: true,
    websiteUrl: 'https://aljawadain.org/home',
    type: 'website',
  },
];

export default function LiveStreamPage() {
  const [playing, setPlaying] = useState<Stream | null>(null);
  const [showPlayer, setShowPlayer] = useState(false);

  const startStream = (stream: Stream) => {
    if (stream.type === 'website' && stream.websiteUrl) {
      // فتح الموقع الرسمي في نافذة جديدة
      window.open(stream.websiteUrl, '_blank');
    } else {
      setPlaying(stream);
      setShowPlayer(true);
    }
  };

  const stopStream = () => {
    setShowPlayer(false);
    setTimeout(() => setPlaying(null), 300);
  };

  return (
    <div className="p-4 space-y-4">
      {/* Hero */}
      <div className="bg-gradient-to-br from-red-600 to-rose-700 rounded-3xl p-6 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-white live-dot"></div>
            <span className="text-sm font-medium">مباشر الآن</span>
          </div>
          <h2 className="font-display text-2xl font-bold mb-2">البث المباشر للعتبات المقدسة</h2>
          <p className="opacity-90 text-sm">تابع الصلوات والزيارات مباشرة من الحرمين الشريفين والعتبات المقدسة</p>
          <div className="flex gap-3 mt-4">
            <div className="bg-white/15 rounded-xl px-3 py-2">
              <p className="text-xs opacity-80">بث مباشر</p>
              <p className="font-bold">{streams.length} قنوات</p>
            </div>
            <div className="bg-white/15 rounded-xl px-3 py-2">
              <p className="text-xs opacity-80">جودة البث</p>
              <p className="font-bold">HD</p>
            </div>
          </div>
        </div>
      </div>

      {/* Video Player Modal */}
      {showPlayer && playing && playing.type === 'video' && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4">
          <div className="w-full max-w-4xl">
            <div className="flex items-center justify-between mb-4 text-white">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-red-500 live-dot"></div>
                <h3 className="font-bold">{playing.title}</h3>
              </div>
              <button
                onClick={stopStream}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="relative aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl">
              <iframe
                className="absolute inset-0 w-full h-full"
                src={
                  playing.youtubeUrl
                    ? `${playing.youtubeUrl}&autoplay=1`
                    : `https://www.youtube.com/embed/${playing.youtubeVideo}?autoplay=1&mute=0&rel=0`
                }
                title={playing.title}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                referrerPolicy="strict-origin-when-cross-origin"
              />
            </div>

            <div className="mt-4 flex items-center justify-between text-white">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Signal className="w-4 h-4" />
                  <span className="text-sm">HD</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm">👁 {playing.viewers.toLocaleString('ar-EG')} مشاهد</span>
                </div>
              </div>
              <a
                href={`https://www.youtube.com/watch?v=${playing.youtubeVideo}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors text-sm"
              >
                <ExternalLink className="w-4 h-4" />
                فتح في YouTube
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Featured live player */}
      <div className="bg-[var(--color-bg-elevated)] rounded-2xl overflow-hidden border border-[var(--color-border)]">
        <div className="relative aspect-video bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex items-center justify-center">
          <div className="absolute inset-0 opacity-20 islamic-pattern"></div>
          <div className="text-center relative">
            <div className="text-8xl mb-4">{playing?.thumbnail || '🕋'}</div>
            {playing ? (
              <div>
                <div className="flex items-center gap-2 justify-center mb-2">
                  <div className="w-2 h-2 rounded-full bg-red-500 live-dot"></div>
                  <span className="text-white text-sm">مباشر</span>
                </div>
                <p className="text-white font-bold">{playing.title}</p>
              </div>
            ) : (
              <p className="text-white/70 text-sm">اختر قناة للبدء</p>
            )}
          </div>
          {playing && (
            <div className="absolute top-3 right-3 bg-black/50 backdrop-blur-sm rounded-lg px-2 py-1 flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-red-500 live-dot"></div>
              <span className="text-white text-xs font-bold">LIVE</span>
            </div>
          )}
          <div className="absolute bottom-3 left-3 bg-black/50 backdrop-blur-sm rounded-lg px-2 py-1">
            <span className="text-white text-xs">HD</span>
          </div>
        </div>
        <div className="p-4 flex items-center gap-3">
          <button
            onClick={() => playing ? stopStream() : startStream(streams[0])}
            className="w-12 h-12 rounded-full btn-primary flex items-center justify-center"
          >
            {playing ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 mr-0.5" />}
          </button>
          <div className="flex-1">
            <p className="font-bold">{playing?.title || 'المسجد الحرام'}</p>
            <p className="text-xs text-[var(--color-text-muted)]">جودة عالية • بث مباشر</p>
          </div>
          <button className="p-2 rounded-full hover:bg-[var(--color-surface)]">
            <Volume2 className="w-5 h-5" />
          </button>
          <button 
            onClick={() => playing && setShowPlayer(true)}
            className="p-2 rounded-full hover:bg-[var(--color-surface)]"
          >
            <Maximize2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* All streams */}
      <div>
        <h3 className="font-display font-bold text-lg mb-3 px-1">جميع القنوات</h3>
        <div className="space-y-2">
          {streams.map((s) => (
            <button
              key={s.id}
              onClick={() => startStream(s)}
              className={`w-full rounded-2xl p-4 border card-hover flex items-center gap-3 text-right ${
                playing?.id === s.id ? 'bg-[var(--color-primary-light)] border-[var(--color-primary)]' : 'bg-[var(--color-bg-elevated)] border-[var(--color-border)]'
              }`}
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-950 flex items-center justify-center text-3xl shadow-inner">
                {s.thumbnail}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  {s.live && (
                    <span className="text-[10px] bg-red-500 text-white px-1.5 py-0.5 rounded font-bold flex items-center gap-1">
                      <div className="w-1 h-1 rounded-full bg-white live-dot"></div>
                      LIVE
                    </span>
                  )}
                  <p className="font-bold text-sm">{s.title}</p>
                </div>
                <p className="text-xs text-[var(--color-text-muted)]">{s.location}</p>
                <div className="flex items-center gap-3 mt-1 text-xs text-[var(--color-text-subtle)]">
                  <span className="flex items-center gap-1">
                    <Signal className="w-3 h-3" /> 
                    {s.type === 'website' ? 'الموقع الرسمي' : s.type === 'video' ? 'فيديو' : 'صوت'}
                  </span>
                  <span>👁 {s.viewers.toLocaleString('ar-EG')} مشاهد</span>
                </div>
              </div>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                playing?.id === s.id 
                  ? 'bg-[var(--color-primary)] text-white' 
                  : s.type === 'website'
                    ? 'bg-[var(--color-accent-light)] text-[var(--color-accent)]'
                    : 'bg-[var(--color-surface)]'
              }`}>
                {s.type === 'website' ? <ExternalLink className="w-4 h-4" /> : playing?.id === s.id ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 mr-0.5" />}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Info card */}
      <div className="bg-[var(--color-accent-light)] rounded-2xl p-4 border border-[var(--color-accent)]">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-[var(--color-accent)] flex items-center justify-center flex-shrink-0">
            <Radio className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <h4 className="font-bold mb-1 text-[var(--color-accent)]">ملاحظة مهمة</h4>
            <p className="text-sm text-[var(--color-text)]">
              البث المباشر للحرمين الشريفين عبر YouTube. العتبات المقدسة تفتح المواقع الرسمية في نافذة جديدة للمزيد من المحتوى والبث المباشر.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
