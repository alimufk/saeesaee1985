'use client';

import { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import { 
  MapPin, Navigation, Search, Heart, Share2, ExternalLink, 
  Clock, Loader2, AlertCircle
} from 'lucide-react';

// تحميل Leaflet ديناميكياً فقط في المتصفح مع إصلاح الأيقونات
const MapContainer = dynamic(
  () => import('react-leaflet').then((mod) => {
    // إصلاح أيقونات Leaflet
    if (typeof window !== 'undefined') {
      const L = require('leaflet');
      delete L.Icon.Default.prototype._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
      });
    }
    return mod.MapContainer;
  }),
  { ssr: false, loading: () => <div className="h-full w-full bg-[var(--color-surface)] flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-[var(--color-primary)]" /></div> }
);

const TileLayer = dynamic(
  () => import('react-leaflet').then((mod) => mod.TileLayer),
  { ssr: false }
);

const Marker = dynamic(
  () => import('react-leaflet').then((mod) => mod.Marker),
  { ssr: false }
);

const Popup = dynamic(
  () => import('react-leaflet').then((mod) => mod.Popup),
  { ssr: false }
);

interface Mosque {
  id: string;
  name: string;
  lat: number;
  lon: number;
  distance?: number;
  address?: string;
}

interface UserLocation {
  lat: number;
  lon: number;
}

export default function NearbyMosquesPage() {
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [mosques, setMosques] = useState<Mosque[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [selectedMosque, setSelectedMosque] = useState<Mosque | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    const saved = localStorage.getItem('noor-mosque-favorites');
    if (saved) setFavorites(JSON.parse(saved));
  }, []);

  useEffect(() => {
    if (isClient) {
      getUserLocation();
    }
  }, [isClient]);

  useEffect(() => {
    if (userLocation) {
      fetchNearbyMosques();
    }
  }, [userLocation]);

  const getUserLocation = () => {
    setLoading(true);
    setError(null);

    if (!navigator.geolocation) {
      setError('المتصفح لا يدعم تحديد الموقع');
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const location = {
          lat: position.coords.latitude,
          lon: position.coords.longitude,
        };
        setUserLocation(location);
      },
      (err) => {
        console.error('Geolocation error:', err);
        setError('فشل في تحديد الموقع. يرجى السماح بالوصول للموقع.');
        setLoading(false);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000,
      }
    );
  };

  const fetchNearbyMosques = async () => {
    if (!userLocation) return;

    try {
      setLoading(true);
      
      // استخدام Overpass API للبحث عن المساجد القريبة
      const radius = 5000; // 5 كم
      const query = `
        [out:json][timeout:25];
        (
          node["amenity"="place_of_worship"]["religion"="muslim"](around:${radius},${userLocation.lat},${userLocation.lon});
          way["amenity"="place_of_worship"]["religion"="muslim"](around:${radius},${userLocation.lat},${userLocation.lon});
          relation["amenity"="place_of_worship"]["religion"="muslim"](around:${radius},${userLocation.lat},${userLocation.lon});
        );
        out center;
      `;

      const response = await fetch('https://overpass-api.de/api/interpreter', {
        method: 'POST',
        body: query,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      });

      const data = await response.json();

      const mosquesData: Mosque[] = data.elements
        .map((element: any) => {
          const lat = element.lat || element.center?.lat;
          const lon = element.lon || element.center?.lon;
          
          if (!lat || !lon) return null;

          return {
            id: element.id.toString(),
            name: element.tags?.name || 'مسجد',
            lat,
            lon,
            distance: calculateDistance(userLocation.lat, userLocation.lon, lat, lon),
            address: element.tags?.['addr:street'] || '',
          };
        })
        .filter((m: Mosque | null): m is Mosque => m !== null)
        .sort((a: Mosque, b: Mosque) => (a.distance || 0) - (b.distance || 0))
        .slice(0, 20);

      setMosques(mosquesData);
      setLoading(false);
    } catch (err) {
      console.error('Fetch error:', err);
      setError('فشل في تحميل المساجد القريبة');
      setLoading(false);
    }
  };

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const toRad = (deg: number): number => deg * (Math.PI / 180);

  const toggleFavorite = (id: string) => {
    const newFavs = favorites.includes(id) 
      ? favorites.filter(f => f !== id) 
      : [...favorites, id];
    setFavorites(newFavs);
    localStorage.setItem('noor-mosque-favorites', JSON.stringify(newFavs));
  };

  const openInGoogleMaps = (mosque: Mosque) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${mosque.lat},${mosque.lon}`;
    window.open(url, '_blank');
  };

  const shareMosque = (mosque: Mosque) => {
    const text = `${mosque.name}\nالموقع: ${mosque.lat}, ${mosque.lon}`;
    if (navigator.share) {
      navigator.share({
        title: mosque.name,
        text: text,
        url: `https://www.google.com/maps?q=${mosque.lat},${mosque.lon}`,
      });
    } else {
      navigator.clipboard?.writeText(text);
      alert('تم نسخ معلومات المسجد');
    }
  };

  const filteredMosques = searchQuery
    ? mosques.filter(m => m.name.includes(searchQuery))
    : mosques;

  if (!isClient) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-4">
        <Loader2 className="w-12 h-12 text-[var(--color-primary)] animate-spin mb-4" />
        <p className="text-[var(--color-text-muted)]">جارٍ التحميل...</p>
      </div>
    );
  }

  if (loading && !userLocation) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-4">
        <Loader2 className="w-12 h-12 text-[var(--color-primary)] animate-spin mb-4" />
        <p className="text-[var(--color-text-muted)]">جارٍ تحديد موقعك...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-4 text-center">
        <AlertCircle className="w-16 h-16 text-red-500 mb-4" />
        <h3 className="text-xl font-bold mb-2">حدث خطأ</h3>
        <p className="text-[var(--color-text-muted)] mb-4">{error}</p>
        <button
          onClick={getUserLocation}
          className="px-6 py-3 bg-[var(--color-primary)] text-white rounded-xl font-medium"
        >
          إعادة المحاولة
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--color-bg)]">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[var(--color-bg)] border-b border-[var(--color-border)]">
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">المساجد القريبة</h1>
            <button
              onClick={getUserLocation}
              className="p-2 rounded-full bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]"
            >
              <Navigation className="w-5 h-5" />
            </button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--color-text-subtle)]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن مسجد..."
              className="w-full pr-10 pl-4 py-3 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl focus:outline-none focus:border-[var(--color-primary)]"
            />
          </div>
        </div>
      </div>

      {/* Map */}
      {userLocation && (
        <div className="relative h-[400px] w-full bg-[var(--color-surface)] border-b border-[var(--color-border)]">
          <MapContainer
            center={[userLocation.lat, userLocation.lon]}
            zoom={14}
            style={{ height: '100%', width: '100%' }}
            scrollWheelZoom={true}
            zoomControl={true}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            {/* علامة موقع المستخدم */}
            <Marker position={[userLocation.lat, userLocation.lon]}>
              <Popup>
                <div style={{ direction: 'rtl', textAlign: 'right' }}>
                  <p style={{ fontWeight: 'bold', marginBottom: '4px' }}>📍 موقعك الحالي</p>
                </div>
              </Popup>
            </Marker>

            {/* علامات المساجد */}
            {mosques.map((mosque) => (
              <Marker
                key={mosque.id}
                position={[mosque.lat, mosque.lon]}
                eventHandlers={{
                  click: () => setSelectedMosque(mosque),
                }}
              >
                <Popup>
                  <div style={{ direction: 'rtl', textAlign: 'right', minWidth: '150px' }}>
                    <p style={{ fontWeight: 'bold', marginBottom: '4px' }}>🕌 {mosque.name}</p>
                    {mosque.distance && (
                      <p style={{ fontSize: '12px', color: '#666', marginBottom: '4px' }}>
                        📏 {mosque.distance < 1 
                          ? `${Math.round(mosque.distance * 1000)} متر`
                          : `${mosque.distance.toFixed(2)} كم`
                        }
                      </p>
                    )}
                    <button
                      onClick={() => openInGoogleMaps(mosque)}
                      style={{
                        marginTop: '8px',
                        padding: '4px 12px',
                        backgroundColor: '#0d6b4e',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '12px',
                      }}
                    >
                      🧭 ملاحة
                    </button>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>

          {loading && (
            <div className="absolute inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-10">
              <div className="bg-[var(--color-bg-elevated)] rounded-xl p-4 flex items-center gap-3">
                <Loader2 className="w-6 h-6 text-[var(--color-primary)] animate-spin" />
                <span className="text-sm font-medium">جارٍ تحميل المساجد...</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Mosques List */}
      <div className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold">
            المساجد القريبة ({filteredMosques.length})
          </h2>
        </div>

        {filteredMosques.length === 0 ? (
          <div className="text-center py-12">
            <MapPin className="w-16 h-16 text-[var(--color-text-subtle)] mx-auto mb-4" />
            <p className="text-[var(--color-text-muted)]">
              {searchQuery ? 'لا توجد نتائج' : 'لم يتم العثور على مساجد قريبة'}
            </p>
          </div>
        ) : (
          filteredMosques.map((mosque) => (
            <div
              key={mosque.id}
              className="bg-[var(--color-surface)] rounded-xl p-4 border border-[var(--color-border)]"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h3 className="font-bold text-lg mb-1">{mosque.name}</h3>
                  {mosque.distance && (
                    <div className="flex items-center gap-2 text-[var(--color-text-muted)]">
                      <Navigation className="w-4 h-4" />
                      <span className="text-sm">
                        {mosque.distance < 1 
                          ? `${Math.round(mosque.distance * 1000)} متر`
                          : `${mosque.distance.toFixed(2)} كم`
                        }
                      </span>
                    </div>
                  )}
                </div>
                <button
                  onClick={() => toggleFavorite(mosque.id)}
                  className={`p-2 rounded-full ${
                    favorites.includes(mosque.id)
                      ? 'text-red-500 bg-red-500/10'
                      : 'text-[var(--color-text-subtle)] hover:bg-[var(--color-surface-variant)]'
                  }`}
                >
                  <Heart className={`w-5 h-5 ${favorites.includes(mosque.id) ? 'fill-current' : ''}`} />
                </button>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => openInGoogleMaps(mosque)}
                  className="flex-1 flex items-center justify-center gap-2 py-2 bg-[var(--color-primary)] text-white rounded-lg font-medium"
                >
                  <Navigation className="w-4 h-4" />
                  <span>ملاحة</span>
                </button>
                <button
                  onClick={() => shareMosque(mosque)}
                  className="p-2 bg-[var(--color-surface-variant)] rounded-lg hover:bg-[var(--color-border)]"
                >
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
