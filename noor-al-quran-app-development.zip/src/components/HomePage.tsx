'use client';

import { BookOpen, Sparkles, Heart, Clock, Beaker, Calendar, Library, Radio, Brain, ChevronLeft, Bookmark, Volume2, Mic, MapPin, Image as ImageIcon, Navigation, Moon as MoonIcon } from 'lucide-react';
import { dailyVerse, dailyHadith } from '@/data/library';

const prayerTimes = [
  { name: 'الفجر', time: '05:12', icon: '🌅' },
  { name: 'الشروق', time: '06:34', icon: '☀️' },
  { name: 'الظهر', time: '12:15', icon: '🌞' },
  { name: 'العصر', time: '15:42', icon: '🌤️' },
  { name: 'المغرب', time: '18:03', icon: '🌇' },
  { name: 'العشاء', time: '19:31', icon: '🌙' },
];

const quickAccess = [
  { id: 'quran', label: 'القرآن', icon: BookOpen, gradient: 'from-emerald-500 to-teal-600' },
  { id: 'reciters', label: 'التلاوة', icon: Mic, gradient: 'from-teal-500 to-emerald-600' },
  { id: 'azkar', label: 'الأذكار', icon: Sparkles, gradient: 'from-amber-500 to-orange-600' },
  { id: 'duas', label: 'الأدعية', icon: Heart, gradient: 'from-rose-500 to-pink-600' },
  { id: 'prayer', label: 'الصلاة', icon: Clock, gradient: 'from-blue-500 to-indigo-600' },
  { id: 'tasbih', label: 'التسبيح', icon: Beaker, gradient: 'from-purple-500 to-violet-600' },
  { id: 'mosques', label: 'المساجد القريبة', icon: Navigation, gradient: 'from-blue-500 to-cyan-600' },
  { id: 'ziyarat', label: 'الزيارات', icon: MapPin, gradient: 'from-orange-500 to-red-600' },
  { id: 'occasions', label: 'المناسبات', icon: Calendar, gradient: 'from-red-500 to-rose-600' },
  { id: 'library', label: 'المكتبة', icon: Library, gradient: 'from-cyan-500 to-sky-600' },
  { id: 'wallpapers', label: 'الخلفيات', icon: ImageIcon, gradient: 'from-pink-500 to-fuchsia-600' },
  { id: 'ramadan', label: 'رمضان وصائمون', icon: MoonIcon, gradient: 'from-purple-600 to-indigo-700' },
  { id: 'live', label: 'البث المباشر', icon: Radio, gradient: 'from-red-600 to-rose-700' },
  { id: 'assistant', label: 'المساعد الذكي', icon: Brain, gradient: 'from-fuchsia-500 to-purple-600' },
];

interface HomePageProps {
  onNavigate: (id: any) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  const nextPrayer = prayerTimes[2]; // مثال: الظهر
  const now = new Date();
  const hijriDate = '15 جمادى الآخرة 1447';
  const gregorianDate = now.toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  return (
    <div className="space-y-4 p-4">
      {/* Hero - Prayer Times Card */}
      <div className="prayer-gradient rounded-3xl p-5 text-white shadow-xl relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
        <div className="relative">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-xs opacity-90">{gregorianDate}</p>
              <p className="text-sm font-medium">{hijriDate}</p>
            </div>
            <div className="text-left">
              <p className="text-xs opacity-90">الصلاة القادمة</p>
              <p className="text-2xl font-bold">{nextPrayer.name}</p>
            </div>
          </div>
          <div className="flex items-end justify-between mb-4">
            <div>
              <p className="text-5xl font-bold font-display tracking-tight">{nextPrayer.time}</p>
              <p className="text-xs opacity-80 mt-1">متبقي 2 ساعة و 14 دقيقة</p>
            </div>
            <div className="text-6xl opacity-50">{nextPrayer.icon}</div>
          </div>
          <div className="grid grid-cols-6 gap-2 pt-3 border-t border-white/20">
            {prayerTimes.map((p) => (
              <div key={p.name} className="text-center">
                <div className="text-lg mb-1">{p.icon}</div>
                <p className="text-[10px] opacity-80">{p.name}</p>
                <p className="text-xs font-bold">{p.time}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Verse of the Day */}
      <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-5 border border-[var(--color-border)] relative">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-lg bg-[var(--color-accent-light)] flex items-center justify-center">
            <BookOpen className="w-4 h-4 text-[var(--color-accent)]" />
          </div>
          <h3 className="font-display font-bold">آية اليوم</h3>
        </div>
        <p className="verse-text text-xl leading-relaxed mb-3">{dailyVerse.text}</p>
        <div className="flex items-center justify-between text-sm text-[var(--color-text-muted)]">
          <span>سورة {dailyVerse.surah} - الآية {dailyVerse.ayah}</span>
          <div className="flex gap-2">
            <button className="p-2 rounded-full hover:bg-[var(--color-surface)]" aria-label="استماع">
              <Volume2 className="w-4 h-4" />
            </button>
            <button className="p-2 rounded-full hover:bg-[var(--color-surface)]" aria-label="حفظ">
              <Bookmark className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Hadith of the Day */}
      <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-5 border border-[var(--color-border)] relative">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-lg bg-[var(--color-primary-light)] flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-[var(--color-primary)]" />
          </div>
          <h3 className="font-display font-bold">حديث اليوم</h3>
        </div>
        <p className="text-lg leading-relaxed mb-2">{dailyHadith.text}</p>
        <p className="text-sm text-[var(--color-text-muted)]">{dailyHadith.narrator}</p>
      </div>

      {/* Last Read */}
      <button
        onClick={() => onNavigate('quran')}
        className="w-full bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] card-hover flex items-center gap-3 text-right"
      >
        <div className="w-12 h-12 rounded-xl bg-[var(--color-primary-light)] flex items-center justify-center">
          <Bookmark className="w-5 h-5 text-[var(--color-primary)]" />
        </div>
        <div className="flex-1">
          <p className="text-xs text-[var(--color-text-muted)]">آخر قراءة</p>
          <p className="font-bold">سورة البقرة - آية 255</p>
          <p className="text-xs text-[var(--color-text-muted)]">آية الكرسي</p>
        </div>
        <ChevronLeft className="w-5 h-5 text-[var(--color-text-subtle)] rotate-180" />
      </button>

      {/* Quick Access */}
      <div>
        <h3 className="font-display font-bold text-lg mb-3 px-1">الوصول السريع</h3>
        <div className="grid grid-cols-3 gap-3">
          {quickAccess.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] card-hover flex flex-col items-center gap-2 aspect-square justify-center"
            >
              <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${item.gradient} flex items-center justify-center text-white shadow-lg`}>
                <item.icon className="w-6 h-6" />
              </div>
              <span className="text-xs font-medium text-center">{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-5 border border-[var(--color-border)]">
        <h3 className="font-display font-bold mb-4">إنجازاتي اليوم</h3>
        <div className="grid grid-cols-3 gap-3 text-center">
          <div>
            <div className="text-2xl font-bold text-[var(--color-primary)]">127</div>
            <div className="text-xs text-[var(--color-text-muted)]">تسبيحة</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-[var(--color-accent)]">3</div>
            <div className="text-xs text-[var(--color-text-muted)]">صفحات قرآن</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-[var(--color-primary)]">12</div>
            <div className="text-xs text-[var(--color-text-muted)]">ذكر</div>
          </div>
        </div>
      </div>
    </div>
  );
}
