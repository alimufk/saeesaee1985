'use client';

import { useState } from 'react';
import { ChevronLeft, Volume2, Heart, Search } from 'lucide-react';
import { duaCategories, DuaCategory, Dua } from '@/data/duas';
import * as LucideIcons from 'lucide-react';

export default function DuasPage() {
  const [selected, setSelected] = useState<DuaCategory | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [search, setSearch] = useState('');

  const toggleFav = (id: string) => {
    setFavorites((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id]));
  };

  if (selected) {
    const filtered = selected.duas.filter((d) => d.title.includes(search) || d.text.includes(search));
    return (
      <div className="p-4">
        <button onClick={() => setSelected(null)} className="flex items-center gap-1 text-sm text-[var(--color-text-muted)] mb-4">
          <ChevronLeft className="w-4 h-4 rotate-180" /> كل الأدعية
        </button>

        <div className="bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] rounded-3xl p-6 text-white mb-4">
          <h2 className="font-display text-2xl font-bold">{selected.title}</h2>
          <p className="opacity-90 text-sm mt-1">{selected.description}</p>
        </div>

        <div className="relative mb-4">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--color-text-subtle)]" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث في الأدعية..."
            className="w-full bg-[var(--color-bg-elevated)] border border-[var(--color-border)] rounded-2xl py-3 pr-10 pl-4 text-sm focus:outline-none focus:border-[var(--color-primary)]"
          />
        </div>

        <div className="space-y-3">
          {filtered.map((d) => (
            <DuaCard key={d.id} dua={d} isFav={favorites.includes(d.id)} onToggleFav={toggleFav} />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4">
      <h2 className="font-display text-xl font-bold mb-4">الأدعية</h2>
      <div className="space-y-3">
        {duaCategories.map((cat) => {
          const Icon = (LucideIcons as any)[cat.icon];
          return (
            <button
              key={cat.id}
              onClick={() => setSelected(cat)}
              className="w-full bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] card-hover flex items-center gap-4 text-right"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] flex items-center justify-center text-white shadow-lg">
                {Icon && <Icon className="w-7 h-7" />}
              </div>
              <div className="flex-1">
                <p className="font-bold mb-1">{cat.title}</p>
                <p className="text-xs text-[var(--color-text-muted)]">{cat.description}</p>
                <p className="text-xs text-[var(--color-primary)] mt-1">{cat.duas.length} دعاء</p>
              </div>
              <ChevronLeft className="w-5 h-5 text-[var(--color-text-subtle)] rotate-180" />
            </button>
          );
        })}
      </div>
    </div>
  );
}

function DuaCard({ dua, isFav, onToggleFav }: { dua: Dua; isFav: boolean; onToggleFav: (id: string) => void }) {
  return (
    <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-5 border border-[var(--color-border)]">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <h3 className="font-bold mb-1">{dua.title}</h3>
          {dua.source && <p className="text-xs text-[var(--color-text-muted)]">{dua.source}</p>}
        </div>
        <button onClick={() => onToggleFav(dua.id)} className={`p-2 rounded-full ${isFav ? 'text-rose-500' : 'text-[var(--color-text-subtle)]'}`}>
          <Heart className={`w-5 h-5 ${isFav ? 'fill-current' : ''}`} />
        </button>
      </div>
      <p className="font-quran text-lg leading-loose mb-3 text-[var(--color-text)]">{dua.text}</p>
      {dua.virtue && (
        <div className="bg-[var(--color-accent-light)] rounded-xl p-3 text-sm mb-3">
          <span className="font-bold text-[var(--color-accent)]">الفضل: </span>
          <span>{dua.virtue}</span>
        </div>
      )}
      {dua.hasAudio && (
        <button className="flex items-center gap-2 text-sm text-[var(--color-primary)]">
          <Volume2 className="w-4 h-4" /> استماع
        </button>
      )}
    </div>
  );
}
