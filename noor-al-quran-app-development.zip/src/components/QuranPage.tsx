'use client';

import { useState } from 'react';
import { Search, ChevronLeft, Bookmark, Share2, Copy, Volume2, BookOpen, Info, X, Check, Star } from 'lucide-react';
import { surahs, reciters, tafsirs } from '@/data/quran';

type View = 'list' | 'read';

export default function QuranPage() {
  const [view, setView] = useState<View>('list');
  const [selectedSurah, setSelectedSurah] = useState<number | null>(null);
  const [search, setSearch] = useState('');
  const [tab, setTab] = useState<'surah' | 'juz' | 'bookmarks'>('surah');
  const [bookmarks, setBookmarks] = useState<{ surahId: number; ayah: number }[]>([
    { surahId: 2, ayah: 255 },
  ]);
  const [showPlayer, setShowPlayer] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filtered = surahs.filter((s) => s.name.includes(search) || s.nameEn.toLowerCase().includes(search.toLowerCase()));
  const current = surahs.find((s) => s.id === selectedSurah);

  const openSurah = (id: number) => {
    setSelectedSurah(id);
    setView('read');
  };

  const copy = (text: string, id: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const toggleBookmark = (surahId: number, ayah: number) => {
    const exists = bookmarks.find((b) => b.surahId === surahId && b.ayah === ayah);
    if (exists) {
      setBookmarks(bookmarks.filter((b) => !(b.surahId === surahId && b.ayah === ayah)));
    } else {
      setBookmarks([...bookmarks, { surahId, ayah }]);
    }
  };

  if (view === 'read' && current) {
    return (
      <div className="pb-4">
        {/* Surah header */}
        <div className="bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] text-white p-6 rounded-b-3xl mb-4 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
          <div className="relative text-center">
            <p className="text-sm opacity-90 mb-2">سُورَة</p>
            <h2 className="font-quran text-4xl mb-2">{current.name}</h2>
            <p className="text-sm opacity-90">{current.nameEn} • {current.type} • {current.versesCount} آية</p>
          </div>
        </div>

        {/* Controls */}
        <div className="px-4 mb-3 flex items-center gap-2">
          <button onClick={() => setView('list')} className="flex items-center gap-1 text-sm text-[var(--color-text-muted)]">
            <ChevronLeft className="w-4 h-4 rotate-180" /> الفهرس
          </button>
          <div className="flex-1"></div>
          <button onClick={() => setShowPlayer(!showPlayer)} className="p-2 rounded-full bg-[var(--color-surface)]">
            <Volume2 className="w-4 h-4" />
          </button>
        </div>

        {/* Audio Player */}
        {showPlayer && (
          <div className="mx-4 mb-4 bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)]">
            <p className="text-sm font-bold mb-2">اختر القارئ</p>
            <div className="grid grid-cols-2 gap-2">
              {reciters.map((r) => (
                <button key={r.id} className="p-2 rounded-lg bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)] text-xs">
                  {r.name}
                </button>
              ))}
            </div>
            <div className="mt-3 flex items-center gap-3">
              <button className="w-10 h-10 rounded-full btn-primary flex items-center justify-center">
                <Volume2 className="w-5 h-5" />
              </button>
              <div className="flex-1 h-1 bg-[var(--color-border)] rounded-full">
                <div className="h-full w-1/3 bg-[var(--color-primary)] rounded-full"></div>
              </div>
              <span className="text-xs text-[var(--color-text-muted)]">02:14</span>
            </div>
          </div>
        )}

        {/* Bismillah */}
        {current.id !== 1 && current.id !== 9 && (
          <div className="text-center py-4 px-4">
            <p className="font-quran text-2xl">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>
            <div className="arabesque mt-2"></div>
          </div>
        )}

        {/* Verses */}
        <div className="px-4 space-y-4">
          {current.verses.map((v) => {
            const id = `${current.id}-${v.number}`;
            const isBookmarked = bookmarks.some((b) => b.surahId === current.id && b.ayah === v.number);
            return (
              <div key={id} className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)]">
                <p className="verse-text mb-3">
                  {v.text}
                  <span className="verse-number mr-2">{v.number}</span>
                </p>
                <div className="flex items-center gap-1 pt-3 border-t border-[var(--color-border)]">
                  <button onClick={() => toggleBookmark(current.id, v.number)} className={`p-2 rounded-full hover:bg-[var(--color-surface)] ${isBookmarked ? 'text-[var(--color-accent)]' : ''}`}>
                    <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
                  </button>
                  <button onClick={() => copy(v.text, id)} className="p-2 rounded-full hover:bg-[var(--color-surface)]">
                    {copiedId === id ? <Check className="w-4 h-4 text-[var(--color-success)]" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <button className="p-2 rounded-full hover:bg-[var(--color-surface)]">
                    <Share2 className="w-4 h-4" />
                  </button>
                  <button className="p-2 rounded-full hover:bg-[var(--color-surface)]">
                    <Volume2 className="w-4 h-4" />
                  </button>
                  <button className="p-2 rounded-full hover:bg-[var(--color-surface)]">
                    <Info className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4">
      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--color-text-subtle)]" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث عن سورة أو آية..."
          className="w-full bg-[var(--color-bg-elevated)] border border-[var(--color-border)] rounded-2xl py-3 pr-10 pl-4 text-sm focus:outline-none focus:border-[var(--color-primary)]"
        />
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-4 p-1 bg-[var(--color-surface)] rounded-2xl">
        {[
          { id: 'surah' as const, label: 'السور' },
          { id: 'juz' as const, label: 'الأجزاء' },
          { id: 'bookmarks' as const, label: `المفضلة (${bookmarks.length})` },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${
              tab === t.id ? 'bg-[var(--color-bg-elevated)] text-[var(--color-primary)] shadow' : 'text-[var(--color-text-muted)]'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Surah list */}
      {tab === 'surah' && (
        <div className="space-y-2">
          {filtered.map((s) => (
            <button
              key={s.id}
              onClick={() => openSurah(s.id)}
              className="w-full bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] card-hover flex items-center gap-3 text-right"
            >
              <div className="relative w-12 h-12 flex items-center justify-center">
                <svg viewBox="0 0 100 100" className="w-12 h-12 text-[var(--color-primary)]">
                  <polygon points="50,5 61,35 95,35 68,57 79,90 50,70 21,90 32,57 5,35 39,35" fill="none" stroke="currentColor" strokeWidth="3" />
                </svg>
                <span className="absolute text-xs font-bold text-[var(--color-primary)]">{s.id}</span>
              </div>
              <div className="flex-1">
                <p className="font-quran text-xl">{s.name}</p>
                <p className="text-xs text-[var(--color-text-muted)]">{s.nameEn} • {s.type} • {s.versesCount} آية</p>
              </div>
              <ChevronLeft className="w-5 h-5 text-[var(--color-text-subtle)] rotate-180" />
            </button>
          ))}
        </div>
      )}

      {tab === 'juz' && (
        <div className="grid grid-cols-3 gap-2">
          {Array.from({ length: 30 }, (_, i) => (
            <button key={i} className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] card-hover text-center">
              <p className="text-2xl font-bold text-[var(--color-primary)]">{i + 1}</p>
              <p className="text-xs text-[var(--color-text-muted)]">الجزء</p>
            </button>
          ))}
        </div>
      )}

      {tab === 'bookmarks' && (
        <div className="space-y-2">
          {bookmarks.length === 0 ? (
            <div className="text-center py-12 text-[var(--color-text-muted)]">
              <Star className="w-12 h-12 mx-auto mb-2 opacity-40" />
              <p>لا توجد مفضلات بعد</p>
            </div>
          ) : (
            bookmarks.map((b, i) => {
              const s = surahs.find((x) => x.id === b.surahId);
              if (!s) return null;
              return (
                <button
                  key={i}
                  onClick={() => openSurah(s.id)}
                  className="w-full bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] card-hover flex items-center gap-3 text-right"
                >
                  <div className="w-10 h-10 rounded-xl bg-[var(--color-accent-light)] flex items-center justify-center">
                    <Bookmark className="w-5 h-5 text-[var(--color-accent)] fill-current" />
                  </div>
                  <div className="flex-1 text-right">
                    <p className="font-bold">سورة {s.name}</p>
                    <p className="text-xs text-[var(--color-text-muted)]">الآية {b.ayah}</p>
                  </div>
                </button>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
