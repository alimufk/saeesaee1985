'use client';

import { useState } from 'react';
import { Calendar, Bell, Heart, ChevronLeft } from 'lucide-react';
import { occasions, Occasion } from '@/data/library';

export default function OccasionsPage() {
  const [tab, setTab] = useState<'upcoming' | 'all'>('upcoming');
  const [notifications, setNotifications] = useState(true);

  const getIcon = (type: Occasion['type']) => {
    if (type === 'happy') return '🎉';
    if (type === 'mourning') return '🕯️';
    return '🤲';
  };

  const getColor = (type: Occasion['type']) => {
    if (type === 'happy') return 'from-emerald-500 to-teal-600';
    if (type === 'mourning') return 'from-slate-700 to-slate-900';
    return 'from-indigo-500 to-purple-600';
  };

  return (
    <div className="p-4 space-y-4">
      {/* Calendar header */}
      <div className="bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] rounded-3xl p-6 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="w-5 h-5" />
            <span className="text-sm opacity-90">التقويم الهجري</span>
          </div>
          <p className="font-display text-3xl font-bold mb-1">15 جمادى الآخرة</p>
          <p className="opacity-90">1447 هـ</p>
          <div className="flex gap-3 mt-4">
            <div className="bg-white/15 rounded-xl px-4 py-2">
              <p className="text-xs opacity-80">ميلادي</p>
              <p className="font-bold">8 ديسمبر 2025</p>
            </div>
            <div className="bg-white/15 rounded-xl px-4 py-2">
              <p className="text-xs opacity-80">المناسبة القادمة</p>
              <p className="font-bold text-sm">المولد النبوي</p>
            </div>
          </div>
        </div>
      </div>

      {/* Notifications toggle */}
      <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[var(--color-accent-light)] flex items-center justify-center">
            <Bell className="w-5 h-5 text-[var(--color-accent)]" />
          </div>
          <div>
            <p className="font-bold">تنبيهات المناسبات</p>
            <p className="text-xs text-[var(--color-text-muted)]">إشعار قبل كل مناسبة</p>
          </div>
        </div>
        <button
          onClick={() => setNotifications(!notifications)}
          className={`w-12 h-7 rounded-full transition-colors ${notifications ? 'bg-[var(--color-primary)]' : 'bg-[var(--color-border)]'}`}
        >
          <div className={`w-5 h-5 rounded-full bg-white transition-transform ${notifications ? 'translate-x-[-20px]' : 'translate-x-[4px]'}`} />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-[var(--color-surface)] rounded-2xl">
        <button
          onClick={() => setTab('upcoming')}
          className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${tab === 'upcoming' ? 'bg-[var(--color-bg-elevated)] shadow' : 'text-[var(--color-text-muted)]'}`}
        >
          القادمة
        </button>
        <button
          onClick={() => setTab('all')}
          className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${tab === 'all' ? 'bg-[var(--color-bg-elevated)] shadow' : 'text-[var(--color-text-muted)]'}`}
        >
          جميع المناسبات
        </button>
      </div>

      {/* Occasions list */}
      <div className="space-y-3">
        {occasions.map((o) => (
          <div key={o.id} className="bg-[var(--color-bg-elevated)] rounded-2xl border border-[var(--color-border)] overflow-hidden card-hover">
            <div className={`h-1 bg-gradient-to-l ${getColor(o.type)}`} />
            <div className="p-4 flex items-center gap-4">
              <div className="text-4xl">{getIcon(o.type)}</div>
              <div className="flex-1">
                <div className="flex items-start justify-between mb-1">
                  <h3 className="font-bold">{o.title}</h3>
                  <button className="p-1.5 rounded-full hover:bg-[var(--color-surface)] text-[var(--color-text-subtle)]">
                    <Heart className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-xs text-[var(--color-primary)] font-medium mb-1">{o.hijriDate} • {o.gregorianDate}</p>
                <p className="text-sm text-[var(--color-text-muted)]">{o.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Mini monthly calendar */}
      <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-5 border border-[var(--color-border)]">
        <h3 className="font-display font-bold mb-4">جمادى الآخرة 1447</h3>
        <div className="grid grid-cols-7 gap-1 text-center text-xs">
          {['أح', 'اث', 'ث', 'أر', 'خ', 'ج', 'س'].map((d) => (
            <div key={d} className="text-[var(--color-text-muted)] font-medium py-1">{d}</div>
          ))}
          {Array.from({ length: 30 }, (_, i) => {
            const day = i + 1;
            const isToday = day === 15;
            const isOccasion = day === 17;
            return (
              <div
                key={day}
                className={`aspect-square flex items-center justify-center rounded-lg text-sm ${
                  isToday ? 'bg-[var(--color-primary)] text-white font-bold' :
                  isOccasion ? 'bg-[var(--color-accent-light)] text-[var(--color-accent)] font-bold' :
                  'hover:bg-[var(--color-surface)]'
                }`}
              >
                {day}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
