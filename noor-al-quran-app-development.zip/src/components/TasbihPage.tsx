'use client';

import { useState, useEffect } from 'react';
import { RotateCcw, TrendingUp, Award } from 'lucide-react';

const dhikrOptions = [
  { id: 'subhan', label: 'سبحان الله', arabic: 'سُبْحَانَ اللَّه', target: 33 },
  { id: 'hamd', label: 'الحمد لله', arabic: 'الْحَمْدُ لِلَّه', target: 33 },
  { id: 'akbar', label: 'الله أكبر', arabic: 'اللَّهُ أَكْبَر', target: 34 },
  { id: 'istighfar', label: 'الاستغفار', arabic: 'أَسْتَغْفِرُ اللَّه', target: 100 },
  { id: 'salawat', label: 'الصلاة على النبي', arabic: 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَآلِ مُحَمَّد', target: 100 },
  { id: 'zahra', label: 'تسبيح الزهراء (ع)', arabic: 'الله أكبر 34، الحمد لله 33، سبحان الله 33', target: 100 },
];

export default function TasbihPage() {
  const [selectedDhikr, setSelectedDhikr] = useState(dhikrOptions[0]);
  const [count, setCount] = useState(0);
  const [totalToday, setTotalToday] = useState(127);
  const [rounds, setRounds] = useState(0);

  const increment = () => {
    const newCount = count + 1;
    setCount(newCount);
    setTotalToday((t) => t + 1);
    if (newCount >= selectedDhikr.target) {
      setRounds((r) => r + 1);
      setCount(0);
    }
  };

  const reset = () => {
    setCount(0);
    setRounds(0);
  };

  const progress = (count / selectedDhikr.target) * 100;
  const circumference = 2 * Math.PI * 90;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <div className="p-4 space-y-4">
      {/* Dhikr selector */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
        {dhikrOptions.map((d) => (
          <button
            key={d.id}
            onClick={() => { setSelectedDhikr(d); setCount(0); setRounds(0); }}
            className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-all ${
              selectedDhikr.id === d.id ? 'bg-[var(--color-primary)] text-white shadow-lg' : 'bg-[var(--color-bg-elevated)] border border-[var(--color-border)]'
            }`}
          >
            {d.label}
          </button>
        ))}
      </div>

      {/* Current dhikr card */}
      <div className="bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] rounded-3xl p-6 text-white text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
        <div className="relative">
          <p className="text-sm opacity-90 mb-2">الذكر الحالي</p>
          <h3 className="font-quran text-3xl mb-2">{selectedDhikr.arabic}</h3>
          <p className="text-sm opacity-80">الهدف: {selectedDhikr.target}</p>
        </div>
      </div>

      {/* Main counter */}
      <div className="bg-[var(--color-bg-elevated)] rounded-3xl p-6 border border-[var(--color-border)] flex flex-col items-center">
        <div className="relative w-72 h-72">
          <svg className="w-full h-full -rotate-90">
            <circle cx="144" cy="144" r="130" stroke="var(--color-border)" strokeWidth="8" fill="none" />
            <circle
              cx="144" cy="144" r="130"
              stroke="url(#gradient)" strokeWidth="8" fill="none"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              style={{ transition: 'stroke-dashoffset 0.3s ease' }}
            />
            <defs>
              <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="var(--color-primary)" />
                <stop offset="100%" stopColor="var(--color-accent)" />
              </linearGradient>
            </defs>
          </svg>
          <button
            onClick={increment}
            className="absolute inset-6 rounded-full tasbih-btn flex flex-col items-center justify-center text-white active:scale-95 transition-transform"
          >
            <p className="text-6xl font-bold font-display">{count}</p>
            <p className="text-sm opacity-90 mt-1">من {selectedDhikr.target}</p>
            <p className="text-xs opacity-70 mt-2">اضغط للتسبيح</p>
          </button>
        </div>

        <div className="flex items-center gap-4 mt-6">
          <button onClick={reset} className="p-3 rounded-full bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]">
            <RotateCcw className="w-5 h-5" />
          </button>
          <div className="flex-1 text-center">
            <p className="text-2xl font-bold text-[var(--color-primary)]">{rounds}</p>
            <p className="text-xs text-[var(--color-text-muted)]">دورات</p>
          </div>
          <div className="w-10" />
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] text-center">
          <TrendingUp className="w-5 h-5 mx-auto mb-2 text-[var(--color-primary)]" />
          <p className="text-2xl font-bold text-[var(--color-primary)]">{totalToday}</p>
          <p className="text-xs text-[var(--color-text-muted)]">اليوم</p>
        </div>
        <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] text-center">
          <Award className="w-5 h-5 mx-auto mb-2 text-[var(--color-accent)]" />
          <p className="text-2xl font-bold text-[var(--color-accent)]">7</p>
          <p className="text-xs text-[var(--color-text-muted)]">أيام متتالية</p>
        </div>
        <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] text-center">
          <RotateCcw className="w-5 h-5 mx-auto mb-2 text-[var(--color-primary)]" />
          <p className="text-2xl font-bold">{rounds}</p>
          <p className="text-xs text-[var(--color-text-muted)]">دورات</p>
        </div>
      </div>

      {/* Weekly chart */}
      <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-5 border border-[var(--color-border)]">
        <h3 className="font-display font-bold mb-4">إحصائيات الأسبوع</h3>
        <div className="flex items-end justify-between h-32 gap-2">
          {[85, 120, 95, 150, 110, 180, totalToday].map((v, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div
                className="w-full rounded-t-lg bg-gradient-to-t from-[var(--color-primary)] to-[var(--color-accent)]"
                style={{ height: `${(v / 200) * 100}%`, minHeight: '10%' }}
              />
              <span className="text-xs text-[var(--color-text-muted)]">
                {['س', 'أ', 'ث', 'ر', 'خ', 'ج', 'س'][i]}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
