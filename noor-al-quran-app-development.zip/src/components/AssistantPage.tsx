'use client';

import { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, BookOpen, User, Copy, Check } from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  source?: string;
}

const suggestedQuestions = [
  'ما هي فضائل سورة الفاتحة؟',
  'كيف أقرأ دعاء كميل؟',
  'ما حكم صلاة الجماعة؟',
  'ما هي آداب قراءة القرآن؟',
  'اقترح لي ورداً يومياً',
  'ما هي علامات ليلة القدر؟',
];

const cannedResponses: Record<string, { text: string; source?: string }> = {
  'الفاتحة': {
    text: 'سورة الفاتحة هي أم الكتاب وأم القرآن، وهي السبع المثاني والقرآن العظيم الذي أوتيه النبي (ص). قال رسول الله (ص): "لا صلاة لمن لم يقرأ بفاتحة الكتاب". من فضائلها: قراءتها في كل ركعة من الصلاة، وهي رقية شرعية، وفيها شفاء من الأمراض.',
    source: 'من تفسير الميزان والتفسير الميسر',
  },
  'كميل': {
    text: 'دعاء كميل بن زياد النخعي، من الأدعية المأثورة عن أمير المؤمنين (ع). يُستحب قراءته ليلة الجمعة. يبدأ بـ: "اللَّهُمَّ إِنِّي أَسْأَلُكَ بِرَحْمَتِكَ الَّتِي وَسِعَتْ كُلَّ شَيْءٍ..." ومن فوائده: المغفرة، قضاء الحوائج، ودفع البلاء.',
    source: 'مفاتيح الجنان - الشيخ عباس القمي',
  },
  'الجماعة': {
    text: 'صلاة الجماعة مستحبة مؤكدة جداً في الإسلام، وقد وردت روايات كثيرة في فضلها. قال النبي (ص): "صلاة الجماعة أفضل من صلاة الفذ بسبع وعشرين درجة". وتجب الجماعة عند بعض الفقهاء في الصلوات اليومية للرجال المقيمين.',
    source: 'من كتاب فقه الإمامية',
  },
  'ورد': {
    text: 'وردك اليومي المقترح:\n\n• قراءة سورة الفاتحة + الإخلاص 7 مرات\n• آية الكرسي 3 مرات\n• الاستغفار 100 مرة\n• الصلاة على محمد وآل محمد 100 مرة\n• تسبيح الزهراء (ع) بعد كل صلاة\n• قراءة صفحة من القرآن\n\nحفظك الله وسدد خطاك.',
  },
  'القadr': {
    text: 'ليلة القدر هي الليلة المباركة التي أُنزل فيها القرآن، وهي خير من ألف شهر. من علاماتها:\n• ليلة صافية ساكنة\n• لا حارة ولا باردة\n• الشمس تطلع في صبيحتها بلا شعاع\n• يشعر المؤمن فيها بالسكينة والطمأنينة\nيُستحب إحياؤها في ليالي 19، 21، 23 من شهر رمضان.',
    source: 'من تفسير القرآن الكريم',
  },
};

function getResponse(query: string): { text: string; source?: string } {
  const q = query.toLowerCase();
  for (const [key, val] of Object.entries(cannedResponses)) {
    if (q.includes(key.toLowerCase())) return val;
  }
  if (q.includes('قرآن') || q.includes('آداب')) {
    return {
      text: 'من آداب قراءة القرآن:\n• الطهارة من الحدث الأصغر والأكبر\n• استقبال القبلة إن أمكن\n• الاستعاذة والبسملة\n• التدبر والخشوع\n• تحسين الصوت بالقراءة\n• عدم الاستعجال\n• السكوت عند القراءة',
      source: 'من كتاب آداب تلاوة القرآن',
    };
  }
  return {
    text: 'شكراً لسؤالك. هذا سؤال مهم. للإجابة عنه بدقة، يُنصح بالرجوع إلى المراجع الدينية المختصة أو البحث في مصادر التفسير المعتمدة مثل تفسير الميزان أو التفسير الميسر.\n\nيمكنك أيضاً البحث في قسم الأدعية أو المكتبة في التطبيق للحصول على إجابات شاملة.',
  };
}

export default function AssistantPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      text: 'السلام عليكم ورحمة الله وبركاته 🌿\n\nأنا مساعدك الإسلامي الذكي، يمكنني الإجابة عن أسئلتك الدينية، البحث في القرآن والأدعية، واقتراح أوراد يومية. كيف يمكنني خدمتك؟',
    },
  ]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, typing]);

  const send = (text: string) => {
    if (!text.trim()) return;
    const userMsg: Message = { id: Date.now().toString(), role: 'user', text };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setTyping(true);

    setTimeout(() => {
      const response = getResponse(text);
      const asstMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        text: response.text,
        source: response.source,
      };
      setMessages((m) => [...m, asstMsg]);
      setTyping(false);
    }, 1000);
  };

  const copy = (text: string, id: string) => {
    navigator.clipboard?.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 1500);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)]">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((m) => (
          <div key={m.id} className={`flex gap-2 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${
              m.role === 'user' ? 'bg-[var(--color-primary)] text-white' : 'bg-[var(--color-accent-light)] text-[var(--color-accent)]'
            }`}>
              {m.role === 'user' ? <User className="w-5 h-5" /> : <Sparkles className="w-5 h-5" />}
            </div>
            <div className={`max-w-[80%] rounded-2xl p-4 ${
              m.role === 'user' ? 'bg-[var(--color-primary)] text-white rounded-tr-sm' : 'bg-[var(--color-bg-elevated)] border border-[var(--color-border)] rounded-tl-sm'
            }`}>
              <p className="whitespace-pre-wrap leading-relaxed text-sm">{m.text}</p>
              {m.source && (
                <div className="mt-2 pt-2 border-t border-[var(--color-border)] flex items-center gap-1 text-xs text-[var(--color-text-muted)]">
                  <BookOpen className="w-3 h-3" />
                  <span>{m.source}</span>
                </div>
              )}
              {m.role === 'assistant' && (
                <button
                  onClick={() => copy(m.text, m.id)}
                  className="mt-2 text-xs text-[var(--color-text-muted)] hover:text-[var(--color-primary)] flex items-center gap-1"
                >
                  {copied === m.id ? <><Check className="w-3 h-3" /> تم النسخ</> : <><Copy className="w-3 h-3" /> نسخ</>}
                </button>
              )}
            </div>
          </div>
        ))}

        {typing && (
          <div className="flex gap-2">
            <div className="w-9 h-9 rounded-full bg-[var(--color-accent-light)] text-[var(--color-accent)] flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="bg-[var(--color-bg-elevated)] border border-[var(--color-border)] rounded-2xl rounded-tl-sm p-4">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-[var(--color-primary)] rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                <span className="w-2 h-2 bg-[var(--color-primary)] rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                <span className="w-2 h-2 bg-[var(--color-primary)] rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
              </div>
            </div>
          </div>
        )}

        <div ref={endRef} />
      </div>

      {/* Suggestions */}
      {messages.length <= 1 && (
        <div className="px-4 pb-3">
          <p className="text-xs text-[var(--color-text-muted)] mb-2">أسئلة مقترحة:</p>
          <div className="flex flex-wrap gap-2">
            {suggestedQuestions.map((q) => (
              <button
                key={q}
                onClick={() => send(q)}
                className="px-3 py-1.5 rounded-full bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)] text-xs font-medium"
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="border-t border-[var(--color-border)] p-3 bg-[var(--color-bg-elevated)]">
        <form
          onSubmit={(e) => { e.preventDefault(); send(input); }}
          className="flex gap-2 items-center"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="اسأل سؤالك الديني..."
            className="flex-1 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-[var(--color-primary)]"
          />
          <button type="submit" className="w-11 h-11 rounded-full btn-primary flex items-center justify-center flex-shrink-0" disabled={!input.trim()}>
            <Send className="w-4 h-4 ml-0.5" />
          </button>
        </form>
        <p className="text-center text-[10px] text-[var(--color-text-subtle)] mt-2">
          تنبيه: إجابات المساعد الذكي استرشادية. يُنصح بالرجوع للمراجع الدينية المختصة
        </p>
      </div>
    </div>
  );
}
