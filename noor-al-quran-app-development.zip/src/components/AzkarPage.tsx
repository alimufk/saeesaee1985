'use client';

import { useState } from 'react';
import { ChevronLeft, RotateCcw, Volume2, Share2, Check } from 'lucide-react';
import { azkarCategories, Dhikr, DhikrCategory } from '@/data/azkar';
import * as LucideIcons from 'lucide-react';

export default function AzkarPage() {
  const [selected, setSelected] = useState<DhikrCategory | null>(null);
  const [selectedDhikr, setSelectedDhikr] = useState<Dhikr | null>(null);
  const [count, setCount] = useState(0);

  const reset = () => setCount(0);
  const increment = () => {
    if (!selectedDhikr) return;
    if (count < selectedDhikr.count) setCount(count + 1);
  };

  if (selectedDhikr) {
    const done = count >= selectedDhikr.count;
    return (
      <div className="p-4 flex flex-col min-h-[80vh]">
        <button onClick={() => { setSelectedDhikr(null); setCount(0); }} className="flex items-center gap-1 text-sm text-[var(--color-text-muted)] mb-4">
          <ChevronLeft className="w-4 h-4 rotate-180" /> رجوع
        </button>

        <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-5 border border-[var(--color-border)] mb-4">
          <h3 className="font-display font-bold text-lg mb-3 text-[var(--color-primary)]">{selectedDhikr.title}</h3>
          <p className="verse-text text-xl leading-relaxed mb-4">{selectedDhikr.text}</p>
          {selectedDhikr.virtue && (
            <div className="bg-[var(--color-accent-light)] rounded-xl p-3 text-sm text-[var(--color-text)]">
              <span className="font-bold">الفضل: </span>{selectedDhikr.virtue}
            </div>
          )}
        </div>

        <div className="flex-1 flex flex-col items-center justify-center">
          <button
            onClick={increment}
            className={`w-64 h-64 rounded-full flex flex-col items-center justify-center shadow-2xl relative ${done ? 'tasbih-btn opacity-60' : 'tasbih-btn'} ${done ? 'pulse-glow' : ''}`}
          >
            <div className="absolute inset-4 rounded-full border-4 border-white/20 flex items-center justify-center">
              <div className="text-center text-white">
                <p className="text-6xl font-bold font-display">{count}</p>
                <p className="text-sm opacity-90">من {selectedDhikr.count}</p>
              </div>
            </div>
          </button>

          <div className="flex items-center gap-4 mt-6">
            <button onClick={reset} className="p-3 rounded-full bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]">
              <RotateCcw className="w-5 h-5" />
            </button>
            <button className="p-3 rounded-full bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]">
              <Volume2 className="w-5 h-5" />
            </button>
            <button className="p-3 rounded-full bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]">
              <Share2 className="w-5 h-5" />
            </button>
          </div>

          <div className="w-full max-w-xs mt-6">
            <div className="h-2 bg-[var(--color-surface)] rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-l from-[var(--color-primary)] to-[var(--color-accent)] transition-all duration-300"
                style={{ width: `${Math.min(100, (count / selectedDhikr.count) * 100)}%` }}
              />
            </div>
            {done && <p className="text-center mt-3 text-[var(--color-success)] font-bold flex items-center justify-center gap-1"><Check className="w-4 h-4" /> اكتمل</p>}
          </div>
        </div>
      </div>
    );
  }

  if (selected) {
    return (
      <div className="p-4">
        <button onClick={() => setSelected(null)} className="flex items-center gap-1 text-sm text-[var(--color-text-muted)] mb-4">
          <ChevronLeft className="w-4 h-4 rotate-180" /> كل الأذكار
        </button>
        <div className={`rounded-3xl p-6 bg-gradient-to-br ${selected.color} text-white mb-4`}>
          <h2 className="font-display text-2xl font-bold">{selected.title}</h2>
          <p className="opacity-90 text-sm mt-1">{selected.items.length} ذكر</p>
        </div>
        <div className="space-y-3">
          {selected.items.map((d) => (
            <button
              key={d.id}
              onClick={() => { setSelectedDhikr(d); setCount(0); }}
              className="w-full bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] card-hover text-right"
            >
              <p className="font-bold mb-1">{d.title}</p>
              <p className="text-sm text-[var(--color-text-muted)] line-clamp-2 mb-2 font-quran">{d.text.slice(0, 80)}...</p>
              <div className="flex items-center justify-between text-xs">
                <span className="text-[var(--color-text-muted)]">التكرار: {d.count}</span>
                <ChevronLeft className="w-4 h-4 rotate-180 text-[var(--color-text-subtle)]" />
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4">
      <h2 className="font-display text-xl font-bold mb-4">الأذكار</h2>
      <div className="grid grid-cols-2 gap-3">
        {azkarCategories.map((cat) => {
          const Icon = (LucideIcons as any)[cat.icon];
          return (
            <button
              key={cat.id}
              onClick={() => setSelected(cat)}
              className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] card-hover text-right relative overflow-hidden"
            >
              <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${cat.color} flex items-center justify-center text-white mb-3 shadow-lg`}>
                {Icon && <Icon className="w-6 h-6" />}
              </div>
              <p className="font-bold mb-1">{cat.title}</p>
              <p className="text-xs text-[var(--color-text-muted)]">{cat.items.length} ذكر</p>
            </button>
          );
        })}
      </div>
    </div>
  );
}
