'use client';

import { useState } from 'react';
import { ChevronLeft, Search, BookOpen } from 'lucide-react';
import { books, Book } from '@/data/library';

export default function LibraryPage() {
  const [selected, setSelected] = useState<Book | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<number | null>(null);
  const [search, setSearch] = useState('');

  if (selected && selectedChapter !== null) {
    const chapter = selected.chapters[selectedChapter];
    return (
      <div className="p-4">
        <button onClick={() => setSelectedChapter(null)} className="flex items-center gap-1 text-sm text-[var(--color-text-muted)] mb-4">
          <ChevronLeft className="w-4 h-4 rotate-180" /> رجوع للفهرس
        </button>
        <div className="bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] rounded-2xl p-5 text-white mb-4">
          <p className="text-sm opacity-90 mb-1">{selected.title}</p>
          <h2 className="font-display text-xl font-bold">{chapter.title}</h2>
        </div>
        <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-5 border border-[var(--color-border)]">
          <p className="text-lg leading-loose">{chapter.content}</p>
        </div>
      </div>
    );
  }

  if (selected) {
    return (
      <div className="p-4">
        <button onClick={() => setSelected(null)} className="flex items-center gap-1 text-sm text-[var(--color-text-muted)] mb-4">
          <ChevronLeft className="w-4 h-4 rotate-180" /> رجوع للمكتبة
        </button>
        <div className="bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] rounded-3xl p-6 text-white mb-4 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
          <div className="relative">
            <div className="w-16 h-16 rounded-2xl bg-white/15 flex items-center justify-center mb-3">
              <BookOpen className="w-8 h-8" />
            </div>
            <h2 className="font-display text-2xl font-bold mb-1">{selected.title}</h2>
            <p className="opacity-90 text-sm mb-2">{selected.author}</p>
            <p className="opacity-80 text-sm">{selected.description}</p>
          </div>
        </div>
        <h3 className="font-display font-bold mb-3 px-1">الفهرس</h3>
        <div className="space-y-2">
          {selected.chapters.map((c, i) => (
            <button
              key={i}
              onClick={() => setSelectedChapter(i)}
              className="w-full bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] card-hover flex items-center gap-3 text-right"
            >
              <div className="w-10 h-10 rounded-xl bg-[var(--color-primary-light)] flex items-center justify-center text-[var(--color-primary)] font-bold">
                {i + 1}
              </div>
              <div className="flex-1">
                <p className="font-bold">{c.title}</p>
              </div>
              <ChevronLeft className="w-5 h-5 text-[var(--color-text-subtle)] rotate-180" />
            </button>
          ))}
        </div>
      </div>
    );
  }

  const filtered = books.filter((b) => b.title.includes(search) || b.author.includes(search));

  return (
    <div className="p-4">
      <h2 className="font-display text-xl font-bold mb-4">المكتبة الإسلامية</h2>

      <div className="relative mb-4">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--color-text-subtle)]" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث في المكتبة..."
          className="w-full bg-[var(--color-bg-elevated)] border border-[var(--color-border)] rounded-2xl py-3 pr-10 pl-4 text-sm focus:outline-none focus:border-[var(--color-primary)]"
        />
      </div>

      {/* Featured books */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        {filtered.slice(0, 2).map((b) => (
          <button
            key={b.id}
            onClick={() => setSelected(b)}
            className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] card-hover text-right relative overflow-hidden min-h-[180px]"
          >
            <div className="absolute inset-0 opacity-5 islamic-pattern"></div>
            <div className="relative">
              <div className="w-12 h-16 rounded-lg bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] flex items-center justify-center text-white mb-3 shadow-lg">
                <BookOpen className="w-6 h-6" />
              </div>
              <p className="font-bold mb-1">{b.title}</p>
              <p className="text-xs text-[var(--color-text-muted)]">{b.author}</p>
              <p className="text-xs text-[var(--color-primary)] mt-2">{b.chapters.length} فصل</p>
            </div>
          </button>
        ))}
      </div>

      {/* Other books */}
      <h3 className="font-display font-bold mb-3 px-1">جميع الكتب</h3>
      <div className="space-y-2">
        {filtered.slice(2).map((b) => (
          <button
            key={b.id}
            onClick={() => setSelected(b)}
            className="w-full bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] card-hover flex items-center gap-3 text-right"
          >
            <div className="w-12 h-16 rounded-lg bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] flex items-center justify-center text-white shadow-lg">
              <BookOpen className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <p className="font-bold mb-1">{b.title}</p>
              <p className="text-xs text-[var(--color-text-muted)]">{b.author}</p>
              <p className="text-xs text-[var(--color-text-subtle)] mt-1 line-clamp-1">{b.description}</p>
            </div>
            <ChevronLeft className="w-5 h-5 text-[var(--color-text-subtle)] rotate-180" />
          </button>
        ))}
      </div>
    </div>
  );
}
