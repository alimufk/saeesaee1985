'use client';

import { useState, useEffect, useRef } from 'react';
import { MapPin, Bell, Compass, Volume2, Clock, RefreshCw, Navigation, Check } from 'lucide-react';
import { Coordinates, CalculationMethod, PrayerTimes, Prayer, SunnahTimes, Qibla, Madhab } from 'adhan';

interface MethodOption {
  id: string;
  name: string;
  description: string;
  method: () => ReturnType<typeof CalculationMethod.MuslimWorldLeague>;
}

const calculationMethods: MethodOption[] = [
  { id: 'mwl', name: 'رابطة العالم الإسلامي', description: 'الطريقة الافتراضية', method: CalculationMethod.MuslimWorldLeague },
  { id: 'makkah', name: 'أم القرى - مكة', description: 'للسعودية والخليج', method: CalculationMethod.UmmAlQura },
  { id: 'egypt', name: 'الهيئة المصرية', description: 'مصر وأفريقيا', method: CalculationMethod.Egyptian },
  { id: 'karachi', name: 'جامعة كراتشي', description: 'باكستان والهند', method: CalculationMethod.Karachi },
  { id: 'tehran', name: 'طهران', description: 'إيران - الشيعة', method: CalculationMethod.Tehran },
  { id: 'isna', name: 'أمريكا الشمالية', description: 'ISNA', method: CalculationMethod.NorthAmerica },
  { id: 'turkey', name: 'تركيا', description: 'Diyanet', method: CalculationMethod.Turkey },
  { id: 'dubai', name: 'دبي', description: 'الإمارات', method: CalculationMethod.Dubai },
];

const adhanSounds = ['أذان مكة', 'أذان المدينة', 'أذان مصر', 'أذان تركيا'];

interface Location {
  latitude: number;
  longitude: number;
  city?: string;
  country?: string;
}

export default function PrayerTimesPage() {
  const [location, setLocation] = useState<Location | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedMethod, setSelectedMethod] = useState<string>('mwl');
  const [now, setNow] = useState(new Date());
  const [selectedAdhan, setSelectedAdhan] = useState('أذان مكة');
  const [notifications, setNotifications] = useState(true);
  const [qiblaAngle, setQiblaAngle] = useState<number | null>(null);
  const [deviceHeading, setDeviceHeading] = useState<number | null>(null);
  const [showMethods, setShowMethods] = useState(false);
  const listenerRef = useRef<boolean>(false);

  // Load saved location
  useEffect(() => {
    const saved = localStorage.getItem('noor-location');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setLocation(parsed);
        setLoading(false);
      } catch {}
    }
    const savedMethod = localStorage.getItem('noor-method');
    if (savedMethod) setSelectedMethod(savedMethod);

    // Get fresh location
    getLocation();
  }, []);

  // Update time every second
  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  // Device orientation for qibla compass
  useEffect(() => {
    if (!('ondeviceorientationabsolute' in window || 'DeviceOrientationEvent' in window)) return;

    const handler = (e: DeviceOrientationEvent) => {
      const alpha = e.alpha;
      if (alpha !== null && alpha !== undefined) {
        // Convert to compass heading (0 = North)
        setDeviceHeading((360 - alpha) % 360);
      }
    };

    if (typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
      // iOS 13+
      return;
    } else {
      window.addEventListener('deviceorientationabsolute', handler as EventListener, true);
      window.addEventListener('deviceorientation', handler as EventListener, true);
      return () => {
        window.removeEventListener('deviceorientationabsolute', handler as EventListener, true);
        window.removeEventListener('deviceorientation', handler as EventListener, true);
      };
    }
  }, []);

  const getLocation = async () => {
    setLoading(true);
    setError(null);

    if (!navigator.geolocation) {
      // Fallback: use IP-based location via free API
      await getIpLocation();
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const loc: Location = {
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
        };
        // Try reverse geocoding
        try {
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${loc.latitude}&lon=${loc.longitude}&accept-language=ar`
          );
          const data = await res.json();
          loc.city = data.address?.city || data.address?.town || data.address?.village || data.address?.state || '';
          loc.country = data.address?.country || '';
        } catch {}
        setLocation(loc);
        localStorage.setItem('noor-location', JSON.stringify(loc));
        setLoading(false);
      },
      async (err) => {
        console.warn('Geolocation failed, trying IP:', err);
        await getIpLocation();
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  };

  const getIpLocation = async () => {
    try {
      const res = await fetch('https://ipapi.co/json/');
      const data = await res.json();
      const loc: Location = {
        latitude: data.latitude,
        longitude: data.longitude,
        city: data.city,
        country: data.country_name,
      };
      setLocation(loc);
      localStorage.setItem('noor-location', JSON.stringify(loc));
      setLoading(false);
    } catch (err) {
      // Ultimate fallback: Baghdad
      const loc: Location = {
        latitude: 33.3152,
        longitude: 44.3661,
        city: 'بغداد',
        country: 'العراق',
      };
      setLocation(loc);
      setError('تعذر تحديد الموقع التلقائي، نستخدم الموقع الافتراضي');
      setLoading(false);
    }
  };

  const requestOrientationPermission = async () => {
    if (typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
      try {
        const permission = await (DeviceOrientationEvent as any).requestPermission();
        if (permission === 'granted') {
          // Reload to start listening
          window.location.reload();
        }
      } catch (e) {
        console.error(e);
      }
    }
  };

  // Calculate prayer times
  const getPrayerData = () => {
    if (!location) return null;

    const coords = new Coordinates(location.latitude, location.longitude);
    const methodObj = calculationMethods.find((m) => m.id === selectedMethod)?.method() || CalculationMethod.MuslimWorldLeague();
    const params = methodObj;
    params.madhab = Madhab.Shafi;

    const times = new PrayerTimes(coords, now, params);
    const sunnah = new SunnahTimes(times);
    const qibla = Qibla(coords);

    const prayerList = [
      { name: 'الفجر', time: times.fajr, prayer: Prayer.Fajr, icon: '🌅' },
      { name: 'الشروق', time: times.sunrise, prayer: null, icon: '☀️' },
      { name: 'الظهر', time: times.dhuhr, prayer: Prayer.Dhuhr, icon: '🌞' },
      { name: 'العصر', time: times.asr, prayer: Prayer.Asr, icon: '🌤️' },
      { name: 'المغرب', time: times.maghrib, prayer: Prayer.Maghrib, icon: '🌇' },
      { name: 'العشاء', time: times.isha, prayer: Prayer.Isha, icon: '🌙' },
    ];

    const currentPrayer = times.currentPrayer();
    const nextPrayer = times.nextPrayer();

    return { times, sunnah, qibla, prayerList, currentPrayer, nextPrayer };
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', hour12: false });
  };

  const getTimeRemaining = (target: Date) => {
    const diff = target.getTime() - now.getTime();
    if (diff < 0) return 'انتهت';
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    if (hours > 0) return `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    return `${minutes}:${String(seconds).padStart(2, '0')}`;
  };

  const formatDistance = (km: number) => {
    if (km >= 1000) return `${(km / 1000).toFixed(0)} ألف كم`;
    return `${Math.round(km)} كم`;
  };

  const getQiblaDistance = () => {
    if (!location) return 0;
    const mecca = { lat: 21.4225, lng: 39.8262 };
    const R = 6371;
    const dLat = ((mecca.lat - location.latitude) * Math.PI) / 180;
    const dLng = ((mecca.lng - location.longitude) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((location.latitude * Math.PI) / 180) *
        Math.cos((mecca.lat * Math.PI) / 180) *
        Math.sin(dLng / 2) *
        Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const saveMethod = (id: string) => {
    setSelectedMethod(id);
    localStorage.setItem('noor-method', id);
    setShowMethods(false);
  };

  if (loading) {
    return (
      <div className="p-4 flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-16 h-16 rounded-full prayer-gradient flex items-center justify-center text-white text-3xl mb-4 pulse-glow">
          🕌
        </div>
        <p className="text-lg font-display font-bold mb-2">جارٍ تحديد موقعك...</p>
        <p className="text-sm text-[var(--color-text-muted)]">لحساب مواقيت الصلاة بدقة</p>
      </div>
    );
  }

  const data = getPrayerData();

  if (!data || !location) {
    return (
      <div className="p-4 text-center">
        <p className="text-[var(--color-error)]">حدث خطأ في تحميل مواقيت الصلاة</p>
        <button onClick={getLocation} className="mt-4 px-4 py-2 btn-primary rounded-xl">إعادة المحاولة</button>
      </div>
    );
  }

  const nextPrayerData = data.prayerList.find((p) => p.prayer === data.nextPrayer) || data.prayerList[2];
  const selectedMethodName = calculationMethods.find((m) => m.id === selectedMethod)?.name || '';

  return (
    <div className="p-4 space-y-4">
      {/* Location header */}
      <div className="bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] rounded-3xl p-6 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
        <div className="relative">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              <span className="text-sm opacity-90">موقعك الحالي</span>
            </div>
            <button
              onClick={getLocation}
              className="p-2 rounded-full bg-white/15 hover:bg-white/25 transition-colors"
              aria-label="تحديث الموقع"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
          <h2 className="font-display text-3xl font-bold mb-1">
            {location.city || 'موقعك'}
            {location.country && <span className="text-lg opacity-80">، {location.country}</span>}
          </h2>
          <p className="text-sm opacity-90">
            {location.latitude.toFixed(4)}° • {location.longitude.toFixed(4)}°
          </p>
          <div className="flex gap-2 mt-4">
            <button
              onClick={() => setShowMethods(!showMethods)}
              className="bg-white/15 hover:bg-white/25 rounded-xl px-3 py-2 text-sm text-right transition-colors"
            >
              <p className="opacity-80 text-xs">طريقة الحساب</p>
              <p className="font-bold">{selectedMethodName}</p>
            </button>
            <div className="bg-white/15 rounded-xl px-3 py-2 text-sm">
              <p className="opacity-80 text-xs">المذهب</p>
              <p className="font-bold">الشافعي</p>
            </div>
          </div>
        </div>
      </div>

      {error && (
        <div className="bg-amber-100 dark:bg-amber-900/30 border border-amber-300 dark:border-amber-700 text-amber-800 dark:text-amber-200 rounded-xl p-3 text-sm">
          ⚠️ {error}
        </div>
      )}

      {/* Method selector */}
      {showMethods && (
        <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)]">
          <h3 className="font-display font-bold mb-3">اختر طريقة الحساب</h3>
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {calculationMethods.map((m) => (
              <button
                key={m.id}
                onClick={() => saveMethod(m.id)}
                className={`w-full p-3 rounded-xl text-right flex items-center justify-between ${
                  selectedMethod === m.id
                    ? 'bg-[var(--color-primary-light)] text-[var(--color-primary)] border border-[var(--color-primary)]'
                    : 'bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]'
                }`}
              >
                <div>
                  <p className="font-medium">{m.name}</p>
                  <p className="text-xs text-[var(--color-text-muted)]">{m.description}</p>
                </div>
                {selectedMethod === m.id && <Check className="w-5 h-5" />}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Next prayer */}
      <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-5 border border-[var(--color-border)]">
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm text-[var(--color-text-muted)]">الصلاة القادمة</p>
          <div className="flex items-center gap-1 text-[var(--color-primary)]">
            <Clock className="w-4 h-4" />
            <span className="text-sm font-bold tabular-nums">متبقي {getTimeRemaining(nextPrayerData.time)}</span>
          </div>
        </div>
        <div className="flex items-end justify-between">
          <div>
            <p className="text-4xl font-display font-bold">{nextPrayerData.name}</p>
            <p className="text-5xl font-bold mt-2 text-[var(--color-primary)] tabular-nums">
              {formatTime(nextPrayerData.time)}
            </p>
          </div>
          <div className="text-7xl opacity-40">{nextPrayerData.icon}</div>
        </div>
        <div className="h-2 bg-[var(--color-surface)] rounded-full overflow-hidden mt-4">
          {(() => {
            const prevIdx = data.prayerList.findIndex((p) => p.prayer === data.currentPrayer);
            const nextIdx = data.prayerList.findIndex((p) => p.prayer === data.nextPrayer);
            if (prevIdx < 0 || nextIdx < 0) return <div className="h-full bg-[var(--color-primary)]" style={{ width: '0%' }} />;
            const prevTime = data.prayerList[prevIdx].time.getTime();
            const nextTime = data.prayerList[nextIdx].time.getTime();
            const progress = Math.max(0, Math.min(100, ((now.getTime() - prevTime) / (nextTime - prevTime)) * 100));
            return (
              <div
                className="h-full bg-gradient-to-l from-[var(--color-primary)] to-[var(--color-accent)] transition-all duration-1000"
                style={{ width: `${progress}%` }}
              />
            );
          })()}
        </div>
      </div>

      {/* All prayer times */}
      <div className="bg-[var(--color-bg-elevated)] rounded-2xl border border-[var(--color-border)] overflow-hidden">
        <div className="px-5 py-3 border-b border-[var(--color-border)] flex items-center justify-between">
          <h3 className="font-display font-bold">مواقيت اليوم</h3>
          <span className="text-xs text-[var(--color-text-muted)]">
            {now.toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' })}
          </span>
        </div>
        {data.prayerList.map((p, i) => {
          const isNext = p.prayer === data.nextPrayer;
          const isCurrent = p.prayer === data.currentPrayer;
          const isPast = p.time.getTime() < now.getTime();
          return (
            <div
              key={p.name}
              className={`px-5 py-4 flex items-center justify-between transition-colors ${
                i < data.prayerList.length - 1 ? 'border-b border-[var(--color-border)]' : ''
              } ${isNext ? 'bg-[var(--color-primary-light)]' : ''}`}
            >
              <div className="flex items-center gap-3">
                <span className="text-xl">{p.icon}</span>
                <div>
                  <span className={`font-medium ${isNext ? 'text-[var(--color-primary)]' : ''}`}>{p.name}</span>
                  {isCurrent && (
                    <span className="mr-2 text-[10px] px-1.5 py-0.5 rounded bg-[var(--color-primary)] text-white">الحالية</span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-3">
                {isNext && (
                  <span className="text-xs text-[var(--color-text-muted)] tabular-nums">
                    {getTimeRemaining(p.time)}
                  </span>
                )}
                <span
                  className={`font-bold tabular-nums ${isNext ? 'text-[var(--color-primary)]' : isPast ? 'text-[var(--color-text-muted)]' : ''}`}
                >
                  {formatTime(p.time)}
                </span>
                <button
                  className={`p-1.5 rounded-full hover:bg-[var(--color-surface)] ${isNext ? 'text-[var(--color-primary)]' : 'text-[var(--color-text-subtle)]'}`}
                  aria-label="تنبيه"
                >
                  <Bell className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Sunnah times */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)]">
          <p className="text-xs text-[var(--color-text-muted)] mb-1">منتصف الليل</p>
          <p className="font-bold tabular-nums">{formatTime(data.sunnah.middleOfTheNight)}</p>
        </div>
        <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)]">
          <p className="text-xs text-[var(--color-text-muted)] mb-1">ثلث الليل الأخير</p>
          <p className="font-bold tabular-nums">{formatTime(data.sunnah.lastThirdOfTheNight)}</p>
        </div>
      </div>

      {/* Qibla */}
      <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-5 border border-[var(--color-border)]">
        <h3 className="font-display font-bold mb-4 flex items-center gap-2">
          <Compass className="w-5 h-5" /> اتجاه القبلة
        </h3>
        <div className="flex items-center justify-center">
          <div className="relative w-56 h-56">
            <div className="absolute inset-0 rounded-full border-4 border-[var(--color-border)]"></div>
            <div className="absolute inset-4 rounded-full border-2 border-dashed border-[var(--color-border)]"></div>

            {/* Direction markers */}
            <div className="absolute top-2 left-1/2 -translate-x-1/2 text-xs font-bold text-[var(--color-text-muted)]">ش</div>
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-xs font-bold text-[var(--color-text-muted)]">ج</div>
            <div className="absolute top-1/2 right-2 -translate-y-1/2 text-xs font-bold text-[var(--color-text-muted)]">ش</div>
            <div className="absolute top-1/2 left-2 -translate-y-1/2 text-xs font-bold text-[var(--color-text-muted)]">غ</div>

            {/* Degree markers */}
            {Array.from({ length: 12 }).map((_, i) => {
              const angle = (i * 30) - 90;
              return (
                <div
                  key={i}
                  className="absolute top-1/2 left-1/2 w-0.5 h-2 bg-[var(--color-border)]"
                  style={{
                    transform: `translate(-50%, -50%) rotate(${angle}deg) translateY(-105px)`,
                    transformOrigin: 'center center',
                  }}
                />
              );
            })}

            {/* Compass rotation based on device */}
            <div
              className="absolute inset-0 transition-transform duration-300"
              style={{ transform: deviceHeading !== null ? `rotate(${-deviceHeading}deg)` : undefined }}
            >
              {/* Qibla arrow */}
              <div
                className="absolute top-1/2 left-1/2 origin-bottom"
                style={{
                  transform: `translate(-50%, -100%) rotate(${data.qibla}deg)`,
                  transformOrigin: '50% 100%',
                  height: '45%',
                }}
              >
                <div className="relative h-full w-1 mx-auto bg-gradient-to-t from-[var(--color-primary)] to-[var(--color-accent)] rounded-full">
                  <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-2xl">🕋</div>
                  <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-b-[10px] border-b-[var(--color-accent)]"></div>
                </div>
              </div>

              {/* North arrow */}
              <div
                className="absolute top-1/2 left-1/2 origin-bottom"
                style={{
                  transform: 'translate(-50%, -100%) rotate(0deg)',
                  transformOrigin: '50% 100%',
                  height: '30%',
                }}
              >
                <div className="h-full w-0.5 mx-auto bg-[var(--color-text-subtle)] opacity-40"></div>
              </div>
            </div>

            {/* Center */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-[var(--color-primary)] shadow-lg"></div>
          </div>
        </div>
        <div className="text-center mt-4 space-y-1">
          <p className="text-sm text-[var(--color-text-muted)]">
            اتجاه القبلة: <span className="font-bold text-[var(--color-primary)]">{Math.round(data.qibla)}°</span> من الشمال
          </p>
          <p className="text-sm text-[var(--color-text-muted)]">
            المسافة إلى مكة: <span className="font-bold">{formatDistance(getQiblaDistance())}</span>
          </p>
          {deviceHeading === null && (
            <button
              onClick={requestOrientationPermission}
              className="mt-2 text-xs text-[var(--color-primary)] flex items-center gap-1 mx-auto"
            >
              <Navigation className="w-3 h-3" /> تفعيل البوصلة
            </button>
          )}
        </div>
      </div>

      {/* Adhan settings */}
      <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-5 border border-[var(--color-border)]">
        <h3 className="font-display font-bold mb-4 flex items-center gap-2">
          <Volume2 className="w-5 h-5" /> صوت الأذان
        </h3>
        <div className="space-y-2">
          {adhanSounds.map((a) => (
            <button
              key={a}
              onClick={() => setSelectedAdhan(a)}
              className={`w-full p-3 rounded-xl text-right flex items-center justify-between ${
                selectedAdhan === a
                  ? 'bg-[var(--color-primary-light)] text-[var(--color-primary)] border border-[var(--color-primary)]'
                  : 'bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]'
              }`}
            >
              <span className="font-medium">{a}</span>
              {selectedAdhan === a && <div className="w-2 h-2 rounded-full bg-[var(--color-primary)]" />}
            </button>
          ))}
        </div>
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-[var(--color-border)]">
          <div>
            <p className="font-medium">تنبيهات الأذان</p>
            <p className="text-xs text-[var(--color-text-muted)]">تنبيه قبل كل صلاة</p>
          </div>
          <button
            onClick={() => setNotifications(!notifications)}
            className={`w-12 h-7 rounded-full transition-colors relative ${
              notifications ? 'bg-[var(--color-primary)]' : 'bg-[var(--color-border)]'
            }`}
            aria-label="تبديل التنبيهات"
          >
            <div
              className={`absolute top-1 w-5 h-5 rounded-full bg-white transition-all ${
                notifications ? 'right-1' : 'right-6'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Info */}
      <div className="text-center text-xs text-[var(--color-text-muted)] py-2">
        <p>المواقيت محسوبة محلياً بناءً على موقعك الحقيقي • آخر تحديث: {formatTime(now)}</p>
      </div>
    </div>
  );
}
