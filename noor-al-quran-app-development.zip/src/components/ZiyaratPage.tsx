'use client';

import { useState, useEffect, useRef } from 'react';
import { ChevronLeft, Volume2, Copy, Share2, Check, Calendar, Heart, BookOpen, MapPin, Pause, Play, SkipForward, SkipBack, Gauge } from 'lucide-react';
import { weeklyZiyarat, generalZiyarat, Ziyarat } from '@/data/ziyarat';

const weekDays = [
  { id: 'الأحد', name: 'الأحد', color: 'from-amber-500 to-orange-500', icon: '☀️' },
  { id: 'الاثنين', name: 'الاثنين', color: 'from-emerald-500 to-teal-500', icon: '🌙' },
  { id: 'الثلاثاء', name: 'الثلاثاء', color: 'from-rose-500 to-red-500', icon: '🌹' },
  { id: 'الأربعاء', name: 'الأربعاء', color: 'from-indigo-500 to-purple-500', icon: '💎' },
  { id: 'الخميس', name: 'الخميس', color: 'from-cyan-500 to-blue-500', icon: '✨' },
  { id: 'الجمعة', name: 'الجمعة', color: 'from-yellow-500 to-amber-500', icon: '🕌' },
  { id: 'السبت', name: 'السبت', color: 'from-slate-500 to-slate-700', icon: '🕋' },
];

export default function ZiyaratPage() {
  const [tab, setTab] = useState<'weekly' | 'general'>('weekly');
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [selectedZiyarat, setSelectedZiyarat] = useState<Ziyarat | null>(null);
  const [copied, setCopied] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);

  // Speech Synthesis state
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [rate, setRate] = useState(0.9);
  const [progress, setProgress] = useState(0);
  const [currentCharIndex, setCurrentCharIndex] = useState(0);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const getCurrentDay = (): string => {
    const days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    return days[new Date().getDay()];
  };

  const today = getCurrentDay();

  // Load available voices
  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = window.speechSynthesis?.getVoices() || [];
      // Filter Arabic voices
      const arabicVoices = availableVoices.filter(v => v.lang.startsWith('ar'));
      setVoices(arabicVoices.length > 0 ? arabicVoices : availableVoices.slice(0, 5));
      if (arabicVoices.length > 0) {
        setSelectedVoice(arabicVoices[0]);
      } else if (availableVoices.length > 0) {
        setSelectedVoice(availableVoices[0]);
      }
    };

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }

    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    };
  }, []);

  const stopSpeech = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlaying(false);
    setIsPaused(false);
    setProgress(0);
    setCurrentCharIndex(0);
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
      progressIntervalRef.current = null;
    }
  };

  const playSpeech = (text: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      alert('المتصفح لا يدعم تقنية القراءة الصوتية');
      return;
    }

    // Cancel any existing speech
    window.speechSynthesis.cancel();

    // Clean text for better speech
    const cleanText = text.replace(/\n+/g, '. ').replace(/[\u064B-\u065F\u0670]/g, '');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'ar-SA';
    utterance.rate = rate;
    utterance.pitch = 1;
    utterance.volume = 1;

    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }

    // Track progress
    const startTime = Date.now();
    const estimatedDuration = (cleanText.length / (rate * 15)) * 1000;

    utterance.onboundary = (event) => {
      if (event.charIndex) {
        setCurrentCharIndex(event.charIndex);
        setProgress((event.charIndex / cleanText.length) * 100);
      }
    };

    utterance.onend = () => {
      setIsPlaying(false);
      setIsPaused(false);
      setProgress(100);
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    };

    utterance.onerror = (e) => {
      console.error('Speech error:', e);
      setIsPlaying(false);
      setIsPaused(false);
    };

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    setIsPlaying(true);
    setIsPaused(false);

    // Fallback progress update
    progressIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const p = Math.min(100, (elapsed / estimatedDuration) * 100);
      setProgress(p);
      if (p >= 100 && progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    }, 200);
  };

  const togglePause = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
    } else {
      window.speechSynthesis.pause();
      setIsPaused(true);
    }
  };

  const handleListen = () => {
    if (!selectedZiyarat) return;
    if (isPlaying) {
      stopSpeech();
    } else {
      playSpeech(selectedZiyarat.text);
    }
  };

  const copyText = (text: string) => {
    navigator.clipboard?.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const toggleFavorite = (id: string) => {
    setFavorites((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id]));
  };

  // عرض تفاصيل الزيارة
  if (selectedZiyarat) {
    const hasSpeechSupport = typeof window !== 'undefined' && 'speechSynthesis' in window;

    return (
      <div className="p-4 pb-24">
        <button
          onClick={() => { setSelectedZiyarat(null); stopSpeech(); }}
          className="flex items-center gap-1 text-sm text-[var(--color-text-muted)] mb-4"
        >
          <ChevronLeft className="w-4 h-4 rotate-180" /> رجوع
        </button>

        <div className="bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] rounded-3xl p-6 text-white mb-4 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
          <div className="relative">
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <p className="text-sm opacity-90 mb-1">{selectedZiyarat.imam}</p>
                <h2 className="font-display text-2xl font-bold mb-1">{selectedZiyarat.title}</h2>
                {selectedZiyarat.subtitle && <p className="text-sm opacity-80">{selectedZiyarat.subtitle}</p>}
              </div>
              <button
                onClick={() => toggleFavorite(selectedZiyarat.id)}
                className="p-2 rounded-full bg-white/15 hover:bg-white/25 transition-colors"
              >
                <Heart className={`w-5 h-5 ${favorites.includes(selectedZiyarat.id) ? 'fill-rose-400 text-rose-400' : ''}`} />
              </button>
            </div>
            {selectedZiyarat.when && (
              <div className="flex items-center gap-2 text-sm opacity-90">
                <Calendar className="w-4 h-4" />
                <span>{selectedZiyarat.when}</span>
              </div>
            )}
          </div>
        </div>

        {selectedZiyarat.virtue && (
          <div className="bg-[var(--color-accent-light)] border border-[var(--color-accent)] rounded-2xl p-4 mb-4">
            <p className="font-bold text-[var(--color-accent)] text-sm mb-1">✨ الفضل</p>
            <p className="text-sm">{selectedZiyarat.virtue}</p>
          </div>
        )}

        <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-5 border border-[var(--color-border)] mb-4">
          <p className="font-quran text-lg leading-loose whitespace-pre-line">{selectedZiyarat.text}</p>
        </div>

        {/* Audio Player */}
        {hasSpeechSupport && (
          <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] mb-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] flex items-center justify-center text-white">
                <Volume2 className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <p className="font-bold text-sm">الاستماع الصوتي</p>
                <p className="text-xs text-[var(--color-text-muted)]">
                  {isPlaying ? (isPaused ? 'متوقف مؤقتاً' : 'جاري القراءة...') : 'جاهز للتشغيل'}
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mb-3">
              <div className="h-2 bg-[var(--color-surface)] rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-l from-[var(--color-primary)] to-[var(--color-accent)] transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <p className="text-xs text-[var(--color-text-muted)] mt-1 text-center">
                {Math.round(progress)}%
              </p>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-3 mb-3">
              <button
                onClick={stopSpeech}
                disabled={!isPlaying}
                className="p-2 rounded-full hover:bg-[var(--color-surface)] disabled:opacity-30"
                aria-label="إيقاف"
              >
                <SkipBack className="w-5 h-5" />
              </button>
              <button
                onClick={handleListen}
                className="w-14 h-14 rounded-full btn-primary flex items-center justify-center shadow-lg"
                aria-label={isPlaying ? 'إيقاف' : 'تشغيل'}
              >
                {isPlaying && !isPaused ? (
                  <Pause className="w-6 h-6" />
                ) : (
                  <Play className="w-6 h-6 mr-0.5" />
                )}
              </button>
              <button
                onClick={togglePause}
                disabled={!isPlaying}
                className="p-2 rounded-full hover:bg-[var(--color-surface)] disabled:opacity-30"
                aria-label={isPaused ? 'استئناف' : 'إيقاف مؤقت'}
              >
                {isPaused ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
              </button>
            </div>

            {/* Voice and Speed Settings */}
            <div className="border-t border-[var(--color-border)] pt-3 space-y-3">
              {/* Voice Selection */}
              {voices.length > 0 && (
                <div>
                  <label className="text-xs text-[var(--color-text-muted)] mb-1 block">الصوت:</label>
                  <select
                    value={selectedVoice?.name || ''}
                    onChange={(e) => {
                      const voice = voices.find(v => v.name === e.target.value);
                      if (voice) setSelectedVoice(voice);
                    }}
                    disabled={isPlaying}
                    className="w-full bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg p-2 text-sm focus:outline-none focus:border-[var(--color-primary)]"
                  >
                    {voices.map((voice) => (
                      <option key={voice.name} value={voice.name}>
                        {voice.name} ({voice.lang})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Speed Control */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs text-[var(--color-text-muted)] flex items-center gap-1">
                    <Gauge className="w-3 h-3" /> السرعة:
                  </label>
                  <span className="text-xs font-bold text-[var(--color-primary)]">{rate.toFixed(1)}x</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="1.5"
                  step="0.1"
                  value={rate}
                  onChange={(e) => setRate(parseFloat(e.target.value))}
                  disabled={isPlaying}
                  className="w-full h-1.5 bg-[var(--color-surface)] rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[var(--color-primary)]"
                />
                <div className="flex justify-between text-[10px] text-[var(--color-text-subtle)] mt-1">
                  <span>بطيء</span>
                  <span>عادي</span>
                  <span>سريع</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {!hasSpeechSupport && (
          <div className="bg-amber-100 dark:bg-amber-900/30 border border-amber-300 dark:border-amber-700 text-amber-800 dark:text-amber-200 rounded-2xl p-4 mb-4 text-sm">
            ⚠️ المتصفح لا يدعم تقنية القراءة الصوتية. جرب استخدام Chrome أو Edge.
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-2 sticky bottom-4 bg-[var(--color-bg)] p-2 rounded-2xl border border-[var(--color-border)] shadow-lg">
          <button
            onClick={() => copyText(selectedZiyarat.text)}
            className="flex-1 flex items-center justify-center gap-2 p-3 rounded-xl bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)] transition-colors"
          >
            {copied ? <Check className="w-4 h-4 text-[var(--color-success)]" /> : <Copy className="w-4 h-4" />}
            <span className="text-sm font-medium">{copied ? 'تم النسخ' : 'نسخ'}</span>
          </button>
          <button className="flex-1 flex items-center justify-center gap-2 p-3 rounded-xl bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)] transition-colors">
            <Share2 className="w-4 h-4" />
            <span className="text-sm font-medium">مشاركة</span>
          </button>
        </div>
      </div>
    );
  }

  // عرض زيارات يوم محدد
  if (selectedDay) {
    const dayZiyarat = weeklyZiyarat.filter((z) => z.day === selectedDay);
    const dayInfo = weekDays.find((d) => d.id === selectedDay);
    return (
      <div className="p-4">
        <button onClick={() => setSelectedDay(null)} className="flex items-center gap-1 text-sm text-[var(--color-text-muted)] mb-4">
          <ChevronLeft className="w-4 h-4 rotate-180" /> كل الأيام
        </button>

        <div className={`bg-gradient-to-br ${dayInfo?.color} rounded-3xl p-6 text-white mb-4 relative overflow-hidden`}>
          <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
          <div className="relative flex items-center gap-3">
            <div className="text-5xl">{dayInfo?.icon}</div>
            <div>
              <h2 className="font-display text-2xl font-bold">يوم {selectedDay}</h2>
              <p className="opacity-90 text-sm">{dayZiyarat.length} زيارة متاحة</p>
              {selectedDay === today && (
                <span className="inline-block mt-2 px-3 py-1 bg-white/20 rounded-full text-xs font-bold">
                  اليوم
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-3">
          {dayZiyarat.map((z) => (
            <ZiyaratCard
              key={z.id}
              ziyarat={z}
              onSelect={() => setSelectedZiyarat(z)}
              isFav={favorites.includes(z.id)}
              onToggleFav={() => toggleFavorite(z.id)}
            />
          ))}
        </div>
      </div>
    );
  }

  // عرض القائمة الرئيسية
  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div className="bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] rounded-3xl p-6 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <MapPin className="w-5 h-5" />
            <span className="text-sm opacity-90">الزيارات المأثورة</span>
          </div>
          <h2 className="font-display text-2xl font-bold mb-2">الزيارات</h2>
          <p className="opacity-90 text-sm">زيارة النبي والأئمة الأطهار (ع)</p>
          <div className="flex gap-3 mt-4">
            <div className="bg-white/15 rounded-xl px-3 py-2">
              <p className="text-xs opacity-80">زيارات أسبوعية</p>
              <p className="font-bold">{weeklyZiyarat.length}</p>
            </div>
            <div className="bg-white/15 rounded-xl px-3 py-2">
              <p className="text-xs opacity-80">زيارات عامة</p>
              <p className="font-bold">{generalZiyarat.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Today's Highlight */}
      <div className="bg-[var(--color-accent-light)] border border-[var(--color-accent)] rounded-2xl p-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-[var(--color-accent)] flex items-center justify-center text-white">
            <Calendar className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <p className="font-bold text-[var(--color-accent)]">زيارات اليوم - {today}</p>
            <p className="text-xs text-[var(--color-text-muted)]">
              {weeklyZiyarat.filter((z) => z.day === today).length} زيارة متاحة
            </p>
          </div>
          <button
            onClick={() => setSelectedDay(today)}
            className="px-3 py-1.5 rounded-xl bg-[var(--color-accent)] text-white text-xs font-bold"
          >
            عرض
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-[var(--color-surface)] rounded-2xl">
        <button
          onClick={() => setTab('weekly')}
          className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2 ${
            tab === 'weekly' ? 'bg-[var(--color-bg-elevated)] shadow text-[var(--color-primary)]' : 'text-[var(--color-text-muted)]'
          }`}
        >
          <Calendar className="w-4 h-4" />
          أيام الأسبوع
        </button>
        <button
          onClick={() => setTab('general')}
          className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2 ${
            tab === 'general' ? 'bg-[var(--color-bg-elevated)] shadow text-[var(--color-primary)]' : 'text-[var(--color-text-muted)]'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          عامة
        </button>
      </div>

      {/* Weekly visits - 7 days grid */}
      {tab === 'weekly' && (
        <div>
          <h3 className="font-display font-bold mb-3 px-1">اختر يوم الأسبوع</h3>
          <div className="grid grid-cols-2 gap-3">
            {weekDays.map((day) => {
              const count = weeklyZiyarat.filter((z) => z.day === day.id).length;
              const isToday = day.id === today;
              return (
                <button
                  key={day.id}
                  onClick={() => setSelectedDay(day.id)}
                  className={`rounded-2xl p-4 border card-hover text-right relative overflow-hidden ${
                    isToday ? 'border-2 border-[var(--color-accent)]' : 'border-[var(--color-border)]'
                  }`}
                  style={{ background: 'var(--color-bg-elevated)' }}
                >
                  <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-l ${day.color}`} />
                  <div className="flex items-start justify-between mb-2">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${day.color} flex items-center justify-center text-xl shadow`}>
                      {day.icon}
                    </div>
                    {isToday && (
                      <span className="text-[10px] bg-[var(--color-accent)] text-white px-2 py-0.5 rounded-full font-bold">
                        اليوم
                      </span>
                    )}
                  </div>
                  <p className="font-display font-bold mb-1">{day.name}</p>
                  <p className="text-xs text-[var(--color-text-muted)]">{count} زيارة</p>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* General visits */}
      {tab === 'general' && (
        <div className="space-y-3">
          {generalZiyarat.map((z) => (
            <ZiyaratCard
              key={z.id}
              ziyarat={z}
              onSelect={() => setSelectedZiyarat(z)}
              isFav={favorites.includes(z.id)}
              onToggleFav={() => toggleFavorite(z.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function ZiyaratCard({
  ziyarat,
  onSelect,
  isFav,
  onToggleFav,
}: {
  ziyarat: Ziyarat;
  onSelect: () => void;
  isFav: boolean;
  onToggleFav: () => void;
}) {
  return (
    <button
      onClick={onSelect}
      className="w-full bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] card-hover text-right"
    >
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] flex items-center justify-center text-white flex-shrink-0 shadow-lg">
          {ziyarat.category === 'weekly' ? <Calendar className="w-6 h-6" /> : <BookOpen className="w-6 h-6" />}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-bold mb-0.5">{ziyarat.title}</p>
          <p className="text-xs text-[var(--color-primary)] mb-1">{ziyarat.imam}</p>
          {ziyarat.subtitle && <p className="text-xs text-[var(--color-text-muted)] line-clamp-1">{ziyarat.subtitle}</p>}
          <div className="flex items-center gap-2 mt-2 flex-wrap">
            {ziyarat.when && (
              <span className="text-[10px] bg-[var(--color-surface)] px-2 py-0.5 rounded-full flex items-center gap-1">
                <Calendar className="w-2.5 h-2.5" />
                {ziyarat.when}
              </span>
            )}
            <span className="text-[10px] bg-[var(--color-primary-light)] text-[var(--color-primary)] px-2 py-0.5 rounded-full flex items-center gap-1">
              <Volume2 className="w-2.5 h-2.5" />
              صوتي
            </span>
          </div>
        </div>
        <div className="flex flex-col items-center gap-1">
          <button
            onClick={(e) => { e.stopPropagation(); onToggleFav(); }}
            className={`p-1.5 rounded-full hover:bg-[var(--color-surface)] ${isFav ? 'text-rose-500' : 'text-[var(--color-text-subtle)]'}`}
          >
            <Heart className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
          </button>
          <ChevronLeft className="w-4 h-4 text-[var(--color-text-subtle)] rotate-180" />
        </div>
      </div>
    </button>
  );
}
