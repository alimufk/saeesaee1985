'use client';

import { useState, useEffect, useRef } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Search, Heart, List, X, ChevronLeft, Loader2, Download, Music } from 'lucide-react';
import { surahs } from '@/data/quran';

interface Reciter {
  id: string;
  name: string;
  arabicName: string;
  style?: string;
  rewaya?: string;
  // مصدر mp3quran.net للسور الكاملة
  mp3quranPath: string;
  // مصدر everyayah.com للتلاوات آية بآية
  everyayahPath: string;
}

interface PlaylistItem {
  surahId: number;
  surahName: string;
  url: string;
}

// قائمة القراء الموثقين مع مساراتهم الصحيحة على mp3quran.net و everyayah.com
const reciters: Reciter[] = [
  {
    id: '1',
    name: 'Abdul Basit Abdul Samad',
    arabicName: 'عبد الباسط عبد الصمد',
    style: 'مرتل',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server7.mp3quran.net/basit/',
    everyayahPath: 'Abdul_Basit_Murattal_192kbps',
  },
  {
    id: '2',
    name: 'Mishary Rashid Alafasy',
    arabicName: 'مشاري راشد العفاسي',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/afs/',
    everyayahPath: 'Alafasy_128kbps',
  },
  {
    id: '3',
    name: 'Abdul Rahman Al-Sudais',
    arabicName: 'عبد الرحمن السديس',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server11.mp3quran.net/sds/',
    everyayahPath: 'Abdurrahmaan_As-Sudais_192kbps',
  },
  {
    id: '4',
    name: 'Saud Al-Shuraim',
    arabicName: 'سعود الشريم',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server7.mp3quran.net/shur/',
    everyayahPath: 'Saood_ash-Shuraym_128kbps',
  },
  {
    id: '5',
    name: 'Maher Al Muaiqly',
    arabicName: 'ماهر المعيقلي',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server12.mp3quran.net/maher/',
    everyayahPath: 'MauroAl_Muaiqly_128kbps',
  },
  {
    id: '6',
    name: 'Saad Al-Ghamdi',
    arabicName: 'سعد الغامدي',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server7.mp3quran.net/s_gmd/',
    everyayahPath: 'Saad_Al_Ghamadi_128kbps',
  },
  {
    id: '7',
    name: 'Ahmad Al-Ajmi',
    arabicName: 'أحمد العجمي',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server10.mp3quran.net/ajm/',
    everyayahPath: 'Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah.info',
  },
  {
    id: '8',
    name: 'Hani Ar-Rifai',
    arabicName: 'هاني الرفاعي',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/hani/',
    everyayahPath: 'Hani_Rifai_192kbps',
  },
  {
    id: '9',
    name: 'Mohamed Siddiq Al-Minshawi',
    arabicName: 'محمد صديق المنشاوي',
    style: 'مرتل',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server10.mp3quran.net/minsh/',
    everyayahPath: 'Minshawy_Murattal_128kbps',
  },
  {
    id: '10',
    name: 'Mahmoud Khalil Al-Husary',
    arabicName: 'محمود خليل الحصري',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server13.mp3quran.net/husr/',
    everyayahPath: 'Husary_128kbps',
  },
  {
    id: '11',
    name: 'Abu Bakr Ash-Shatri',
    arabicName: 'أبو بكر الشاطري',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server11.mp3quran.net/shatri/',
    everyayahPath: 'Abu_Bakr_Ash-Shaatree_128kbps',
  },
  {
    id: '12',
    name: 'Nasser Al Qatami',
    arabicName: 'ناصر القطامي',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server11.mp3quran.net/qtm/',
    everyayahPath: 'Nasser_Alqatami_128kbps',
  },
  {
    id: '13',
    name: 'Yasser Ad-Dossari',
    arabicName: 'ياسر الدوسري',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server11.mp3quran.net/yasser/',
    everyayahPath: 'Yasser_Ad-Dussary_128kbps',
  },
  {
    id: '14',
    name: 'Muhammad Ayyub',
    arabicName: 'محمد أيوب',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/ayyub/',
    everyayahPath: 'Muhammad_Ayyoub_128kbps',
  },
  {
    id: '15',
    name: 'Muhammad Jibreel',
    arabicName: 'محمد جبريل',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/jbrl/',
    everyayahPath: 'Muhammad_Jibreel_128kbps',
  },
  {
    id: '16',
    name: 'Abdullah Al-Juhany',
    arabicName: 'عبد الله الجهني',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server11.mp3quran.net/jhn/',
    everyayahPath: 'Abdullah_Juhany_64kbps',
  },
  {
    id: '17',
    name: 'Fares Abbad',
    arabicName: 'فارس عباد',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/frs/',
    everyayahPath: 'Fares_Abbad_128kbps',
  },
  {
    id: '18',
    name: 'Idris Abkar',
    arabicName: 'إدريس أبكر',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server6.mp3quran.net/abkr/',
    everyayahPath: 'Idrees_Akbar_128kbps',
  },
  {
    id: '19',
    name: 'Khalid Al Qahtani',
    arabicName: 'خالد القحطاني',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/qlht/',
    everyayahPath: 'Khaalid_Abdullaah_al-Qahtaanee_192kbps',
  },
  {
    id: '20',
    name: 'Ali Al-Hudhaify',
    arabicName: 'علي الحذيفي',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/hudh/',
    everyayahPath: 'Ali_Hajjaj_AlSouasi_128kbps',
  },
  {
    id: '21',
    name: 'Abdul Muhsin Al Qasim',
    arabicName: 'عبد المحسن القاسم',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/qasm/',
    everyayahPath: 'Abdul_Muhsin_Al_Qasim_192kbps',
  },
  {
    id: '22',
    name: 'Abdullah Matroud',
    arabicName: 'عبد الله مطرود',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/mtrod/',
    everyayahPath: 'Abdullah_Matroud_128kbps',
  },
  {
    id: '23',
    name: 'Muhammad Al Luhaidan',
    arabicName: 'محمد اللحيدان',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/lhdan/',
    everyayahPath: 'Muhammad_Al_Luhaidan_128kbps',
  },
  {
    id: '24',
    name: 'Salah Bukhatir',
    arabicName: 'صلاح بو خاطر',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server12.mp3quran.net/bu_khtr/',
    everyayahPath: 'Salaah_AbdulRahman_Bukhatir_128kbps',
  },
  {
    id: '25',
    name: 'Ahmed Hawashi',
    arabicName: 'أحمد الحواشي',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/hwashi/',
    everyayahPath: 'Ahmed_Hawashi_128kbps',
  },
  {
    id: '26',
    name: 'Abdul Aziz Al-Ahmad',
    arabicName: 'عبد العزيز الأحمد',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/a_ahmed/',
    everyayahPath: 'Abdul_Aziz_Al_Ahmad_128kbps',
  },
  {
    id: '27',
    name: 'Al-Zain Mohammad Ahmed',
    arabicName: 'الزين محمد أحمد',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/zain/',
    everyayahPath: 'Aziz_Alili_128kbps',
  },
  {
    id: '28',
    name: 'Abdullah Basfar',
    arabicName: 'عبد الله بصفر',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server8.mp3quran.net/basf/',
    everyayahPath: 'Abdullah_Basfar_192kbps',
  },
  {
    id: '29',
    name: 'Mohamed Al-Tablawi',
    arabicName: 'محمد الطبلاوي',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server12.mp3quran.net/tblawi/',
    everyayahPath: 'Mohammad_al_Tablaway_128kbps',
  },
  {
    id: '30',
    name: 'Abdul Bari Ath-Thubaity',
    arabicName: 'عبد الباري الثبيتي',
    rewaya: 'حفص عن عاصم',
    mp3quranPath: 'https://server6.mp3quran.net/thubaity/',
    everyayahPath: 'Abdul_Bari_Al-Thubaity_128kbps',
  },
];

// بناء رابط التلاوة الكاملة للسورة من mp3quran.net
const getFullSurahUrl = (reciter: Reciter, surahNumber: number): string => {
  const surahNum = String(surahNumber).padStart(3, '0');
  return `${reciter.mp3quranPath}${surahNum}.mp3`;
};

// بناء رابط تلاوة آية واحدة من everyayah.com
const getAyahUrl = (reciter: Reciter, surahNumber: number, ayahNumber: number): string => {
  const surah = String(surahNumber).padStart(3, '0');
  const ayah = String(ayahNumber).padStart(3, '0');
  return `https://everyayah.com/data/${reciter.everyayahPath}/${surah}${ayah}.mp3`;
};

export default function RecitersPage() {
  const [selectedReciter, setSelectedReciter] = useState<Reciter | null>(null);
  const [search, setSearch] = useState('');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [currentTrack, setCurrentTrack] = useState<PlaylistItem | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playlist, setPlaylist] = useState<PlaylistItem[]>([]);
  const [showPlaylist, setShowPlaylist] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mode, setMode] = useState<'full' | 'ayah'>('full'); // full surah or ayah-by-ayah
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem('noor-reciter-favorites');
    if (saved) setFavorites(JSON.parse(saved));
    const savedMode = localStorage.getItem('noor-reciter-mode');
    if (savedMode === 'ayah' || savedMode === 'full') setMode(savedMode);
  }, []);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const updateDuration = () => setDuration(audio.duration);
    const handleEnded = () => {
      const currentIdx = playlist.findIndex(p => p.surahId === currentTrack?.surahId);
      if (currentIdx < playlist.length - 1) {
        playSurah(playlist[currentIdx + 1].surahId);
      } else {
        setIsPlaying(false);
      }
    };
    const handleError = (e: Event) => {
      console.error('Audio error:', e);
      setError('فشل في تحميل التلاوة. جرب قارئ آخر أو تأكد من اتصال الإنترنت.');
      setIsPlaying(false);
      setLoading(false);
    };
    const handleCanPlay = () => {
      setLoading(false);
      setError(null);
    };
    const handleLoadStart = () => {
      setLoading(true);
      setError(null);
    };

    audio.addEventListener('timeupdate', updateTime);
    audio.addEventListener('loadedmetadata', updateDuration);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);
    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('loadstart', handleLoadStart);

    return () => {
      audio.removeEventListener('timeupdate', updateTime);
      audio.removeEventListener('loadedmetadata', updateDuration);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
      audio.removeEventListener('canplay', handleCanPlay);
      audio.removeEventListener('loadstart', handleLoadStart);
    };
  }, [currentTrack, playlist]);

  const toggleFavorite = (id: string) => {
    const newFavs = favorites.includes(id) ? favorites.filter(f => f !== id) : [...favorites, id];
    setFavorites(newFavs);
    localStorage.setItem('noor-reciter-favorites', JSON.stringify(newFavs));
  };

  const playSurah = (surahId: number) => {
    if (!selectedReciter) return;
    const surah = surahs.find(s => s.id === surahId);
    if (!surah) return;

    setError(null);
    setLoading(true);

    const url = mode === 'full' 
      ? getFullSurahUrl(selectedReciter, surahId)
      : getAyahUrl(selectedReciter, surahId, 1);
    
    const track: PlaylistItem = {
      surahId,
      surahName: surah.name,
      url,
    };

    setCurrentTrack(track);
    
    if (!playlist.find(p => p.surahId === surahId)) {
      setPlaylist([...playlist, track]);
    }

    if (audioRef.current) {
      audioRef.current.src = url;
      audioRef.current.load();
      audioRef.current.play().then(() => {
        setIsPlaying(true);
        setLoading(false);
      }).catch(err => {
        console.error('Failed to play:', err);
        setError('فشل في تشغيل التلاوة');
        setLoading(false);
      });
    }
  };

  const playAllSurahs = () => {
    if (!selectedReciter) return;
    const newPlaylist = surahs.map(s => ({
      surahId: s.id,
      surahName: s.name,
      url: mode === 'full' 
        ? getFullSurahUrl(selectedReciter, s.id)
        : getAyahUrl(selectedReciter, s.id, 1),
    }));
    setPlaylist(newPlaylist);
    playSurah(newPlaylist[0].surahId);
  };

  const togglePlay = () => {
    if (!audioRef.current || !currentTrack) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  };

  const skipNext = () => {
    const currentIdx = playlist.findIndex(p => p.surahId === currentTrack?.surahId);
    if (currentIdx < playlist.length - 1) {
      playSurah(playlist[currentIdx + 1].surahId);
    }
  };

  const skipPrevious = () => {
    const currentIdx = playlist.findIndex(p => p.surahId === currentTrack?.surahId);
    if (currentIdx > 0) {
      playSurah(playlist[currentIdx - 1].surahId);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setCurrentTime(time);
    }
  };

  const handleVolume = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    setVolume(vol);
    if (audioRef.current) {
      audioRef.current.volume = vol;
    }
    setIsMuted(vol === 0);
  };

  const toggleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const formatTime = (time: number): string => {
    if (isNaN(time) || !isFinite(time)) return '0:00';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const switchMode = (newMode: 'full' | 'ayah') => {
    setMode(newMode);
    localStorage.setItem('noor-reciter-mode', newMode);
    // إعادة تشغيل نفس السورة بالوضع الجديد
    if (currentTrack && selectedReciter) {
      playSurah(currentTrack.surahId);
    }
  };

  const filteredReciters = reciters.filter(r => 
    r.arabicName.includes(search) || r.name.toLowerCase().includes(search.toLowerCase())
  );

  // شاشة اختيار القارئ
  if (!selectedReciter) {
    return (
      <div className="p-4 space-y-4">
        <div className="bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] rounded-3xl p-6 text-white relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
          <div className="relative">
            <div className="flex items-center gap-2 mb-2">
              <Music className="w-5 h-5" />
              <h2 className="font-display text-2xl font-bold">التلاوات الصوتية</h2>
            </div>
            <p className="opacity-90 text-sm mb-4">استمع لتلاوات أشهر القراء من كل سورة القرآن الكريم</p>
            <div className="flex gap-3">
              <div className="bg-white/15 rounded-xl px-3 py-2">
                <p className="text-xs opacity-80">القراء</p>
                <p className="font-bold">{reciters.length}</p>
              </div>
              <div className="bg-white/15 rounded-xl px-3 py-2">
                <p className="text-xs opacity-80">السور</p>
                <p className="font-bold">114</p>
              </div>
              <div className="bg-white/15 rounded-xl px-3 py-2">
                <p className="text-xs opacity-80">المصادر</p>
                <p className="font-bold text-xs">mp3quran<br/>everyayah</p>
              </div>
            </div>
          </div>
        </div>

        {/* Mode selector */}
        <div className="bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)]">
          <p className="font-bold mb-3">وضع التشغيل</p>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => switchMode('full')}
              className={`p-3 rounded-xl text-center transition-all ${
                mode === 'full'
                  ? 'bg-[var(--color-primary)] text-white shadow-lg'
                  : 'bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]'
              }`}
            >
              <p className="font-bold text-sm">سورة كاملة</p>
              <p className="text-xs opacity-80 mt-0.5">تشغيل السورة كاملة</p>
            </button>
            <button
              onClick={() => switchMode('ayah')}
              className={`p-3 rounded-xl text-center transition-all ${
                mode === 'ayah'
                  ? 'bg-[var(--color-primary)] text-white shadow-lg'
                  : 'bg-[var(--color-surface)] hover:bg-[var(--color-surface-variant)]'
              }`}
            >
              <p className="font-bold text-sm">آية بآية</p>
              <p className="text-xs opacity-80 mt-0.5">تلاوة مفصلة</p>
            </button>
          </div>
        </div>

        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--color-text-subtle)]" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث عن قارئ..."
            className="w-full bg-[var(--color-bg-elevated)] border border-[var(--color-border)] rounded-2xl py-3 pr-10 pl-4 text-sm focus:outline-none focus:border-[var(--color-primary)]"
          />
        </div>

        {favorites.length > 0 && (
          <div>
            <h3 className="font-display font-bold mb-3 px-1">❤️ المفضلة</h3>
            <div className="space-y-2">
              {reciters.filter(r => favorites.includes(r.id)).map(reciter => (
                <ReciterCard
                  key={reciter.id}
                  reciter={reciter}
                  onSelect={() => setSelectedReciter(reciter)}
                  isFavorite={true}
                  onToggleFavorite={() => toggleFavorite(reciter.id)}
                />
              ))}
            </div>
          </div>
        )}

        <div>
          <h3 className="font-display font-bold mb-3 px-1">🎙️ جميع القراء</h3>
          <div className="space-y-2">
            {filteredReciters.map(reciter => (
              <ReciterCard
                key={reciter.id}
                reciter={reciter}
                onSelect={() => setSelectedReciter(reciter)}
                isFavorite={favorites.includes(reciter.id)}
                onToggleFavorite={() => toggleFavorite(reciter.id)}
              />
            ))}
          </div>
        </div>

        <div className="bg-[var(--color-surface)] rounded-2xl p-4 text-center">
          <p className="text-xs text-[var(--color-text-muted)]">
            🎵 التلاوات من <span className="font-bold text-[var(--color-primary)]">mp3quran.net</span> و <span className="font-bold text-[var(--color-primary)]">everyayah.com</span>
          </p>
        </div>
      </div>
    );
  }

  // شاشة اختيار السورة
  return (
    <div className="p-4 pb-32">
      <button onClick={() => setSelectedReciter(null)} className="flex items-center gap-1 text-sm text-[var(--color-text-muted)] mb-4">
        <ChevronLeft className="w-4 h-4 rotate-180" /> كل القراء
      </button>

      <div className="bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] rounded-3xl p-6 text-white mb-4 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 islamic-pattern"></div>
        <div className="relative">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-16 h-16 rounded-2xl bg-white/15 flex items-center justify-center text-3xl">
              🎙️
            </div>
            <div className="flex-1">
              <h2 className="font-display text-2xl font-bold">{selectedReciter.arabicName}</h2>
              <p className="opacity-90 text-sm">{selectedReciter.rewaya}</p>
              {selectedReciter.style && <p className="opacity-80 text-xs">{selectedReciter.style}</p>}
            </div>
          </div>
          
          {/* Mode toggle */}
          <div className="grid grid-cols-2 gap-2 mb-3">
            <button
              onClick={() => switchMode('full')}
              className={`p-2 rounded-xl text-xs font-medium transition-all ${
                mode === 'full' ? 'bg-white text-[var(--color-primary)]' : 'bg-white/15 hover:bg-white/25'
              }`}
            >
              📖 سورة كاملة
            </button>
            <button
              onClick={() => switchMode('ayah')}
              className={`p-2 rounded-xl text-xs font-medium transition-all ${
                mode === 'ayah' ? 'bg-white text-[var(--color-primary)]' : 'bg-white/15 hover:bg-white/25'
              }`}
            >
              🔢 آية بآية
            </button>
          </div>

          <button
            onClick={playAllSurahs}
            className="w-full bg-white/15 hover:bg-white/25 rounded-xl px-4 py-3 text-sm font-medium transition-colors flex items-center justify-center gap-2"
          >
            <Play className="w-4 h-4" /> تشغيل جميع السور (114)
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-100 dark:bg-red-900/30 border border-red-300 dark:border-red-700 text-red-800 dark:text-red-200 rounded-xl p-3 text-sm mb-4">
          ⚠️ {error}
        </div>
      )}

      <div className="relative mb-4">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--color-text-subtle)]" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث عن سورة..."
          className="w-full bg-[var(--color-bg-elevated)] border border-[var(--color-border)] rounded-2xl py-3 pr-10 pl-4 text-sm focus:outline-none focus:border-[var(--color-primary)]"
        />
      </div>

      <div className="space-y-2 max-h-[60vh] overflow-y-auto">
        {surahs.filter(s => s.name.includes(search)).map(surah => (
          <button
            key={surah.id}
            onClick={() => playSurah(surah.id)}
            className={`w-full rounded-2xl p-4 border card-hover flex items-center gap-3 text-right ${
              currentTrack?.surahId === surah.id && isPlaying
                ? 'bg-[var(--color-primary-light)] border-[var(--color-primary)]'
                : 'bg-[var(--color-bg-elevated)] border-[var(--color-border)]'
            }`}
          >
            <div className="relative w-10 h-10 flex items-center justify-center flex-shrink-0">
              <svg viewBox="0 0 100 100" className="w-10 h-10 text-[var(--color-primary)]">
                <polygon points="50,5 61,35 95,35 68,57 79,90 50,70 21,90 32,57 5,35 39,35" fill="none" stroke="currentColor" strokeWidth="3" />
              </svg>
              <span className="absolute text-xs font-bold text-[var(--color-primary)]">{surah.id}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-quran text-lg">{surah.name}</p>
              <p className="text-xs text-[var(--color-text-muted)]">{surah.versesCount} آية • {surah.type}</p>
            </div>
            {loading && currentTrack?.surahId === surah.id ? (
              <Loader2 className="w-5 h-5 text-[var(--color-primary)] animate-spin" />
            ) : currentTrack?.surahId === surah.id && isPlaying ? (
              <div className="flex gap-1">
                <span className="w-1 h-4 bg-[var(--color-primary)] rounded animate-pulse"></span>
                <span className="w-1 h-4 bg-[var(--color-primary)] rounded animate-pulse" style={{ animationDelay: '0.2s' }}></span>
                <span className="w-1 h-4 bg-[var(--color-primary)] rounded animate-pulse" style={{ animationDelay: '0.4s' }}></span>
              </div>
            ) : (
              <Play className="w-5 h-5 text-[var(--color-text-subtle)]" />
            )}
          </button>
        ))}
      </div>

      {/* Audio Player */}
      {currentTrack && (
        <>
          <audio ref={audioRef} preload="metadata" />
          
          {/* Full Player */}
          <div className="fixed bottom-20 left-1/2 -translate-x-1/2 w-full max-w-[460px] bg-[var(--color-bg-elevated)] border border-[var(--color-border)] rounded-2xl shadow-2xl p-4 z-40">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] flex items-center justify-center text-white text-2xl">
                🎙️
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold truncate">{currentTrack.surahName}</p>
                <p className="text-xs text-[var(--color-text-muted)] truncate">{selectedReciter.arabicName}</p>
              </div>
              <button
                onClick={() => setShowPlaylist(!showPlaylist)}
                className="p-2 rounded-full hover:bg-[var(--color-surface)]"
                aria-label="قائمة التشغيل"
              >
                <List className="w-5 h-5" />
              </button>
            </div>

            <div className="mb-3">
              <input
                type="range"
                min="0"
                max={duration || 0}
                value={currentTime}
                onChange={handleSeek}
                className="w-full h-1.5 bg-[var(--color-border)] rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[var(--color-primary)]"
              />
              <div className="flex justify-between text-xs text-[var(--color-text-muted)] mt-1 tabular-nums">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            <div className="flex items-center justify-center gap-4">
              <button
                onClick={skipPrevious}
                className="p-2 rounded-full hover:bg-[var(--color-surface)]"
                disabled={playlist.findIndex(p => p.surahId === currentTrack?.surahId) === 0}
              >
                <SkipBack className="w-5 h-5" />
              </button>
              <button
                onClick={togglePlay}
                className="w-14 h-14 rounded-full btn-primary flex items-center justify-center"
                disabled={loading}
              >
                {loading ? (
                  <Loader2 className="w-6 h-6 animate-spin" />
                ) : isPlaying ? (
                  <Pause className="w-6 h-6" />
                ) : (
                  <Play className="w-6 h-6 mr-0.5" />
                )}
              </button>
              <button
                onClick={skipNext}
                className="p-2 rounded-full hover:bg-[var(--color-surface)]"
                disabled={playlist.findIndex(p => p.surahId === currentTrack?.surahId) === playlist.length - 1}
              >
                <SkipForward className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center gap-2 mt-3">
              <button onClick={toggleMute} className="p-1.5 rounded-full hover:bg-[var(--color-surface)]">
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={volume}
                onChange={handleVolume}
                className="flex-1 h-1 bg-[var(--color-border)] rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-2.5 [&::-webkit-slider-thumb]:h-2.5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[var(--color-primary)]"
              />
              <a
                href={currentTrack.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1.5 rounded-full hover:bg-[var(--color-surface)]"
                title="تحميل"
              >
                <Download className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Playlist Modal */}
          {showPlaylist && (
            <div className="fixed inset-0 z-50 bg-black/50 flex items-end max-w-[480px] mx-auto">
              <div className="w-full bg-[var(--color-bg)] rounded-t-3xl max-h-[70vh] overflow-hidden flex flex-col">
                <div className="p-4 border-b border-[var(--color-border)] flex items-center justify-between">
                  <h3 className="font-display font-bold">قائمة التشغيل ({playlist.length})</h3>
                  <button onClick={() => setShowPlaylist(false)} className="p-2 rounded-full hover:bg-[var(--color-surface)]">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-2">
                  {playlist.map((item, idx) => (
                    <button
                      key={idx}
                      onClick={() => playSurah(item.surahId)}
                      className={`w-full p-3 rounded-xl flex items-center gap-3 ${
                        currentTrack?.surahId === item.surahId && isPlaying
                          ? 'bg-[var(--color-primary-light)] text-[var(--color-primary)]'
                          : 'hover:bg-[var(--color-surface)]'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-lg bg-[var(--color-primary)] text-white flex items-center justify-center text-sm font-bold">
                        {idx + 1}
                      </div>
                      <span className="flex-1 text-right font-medium">{item.surahName}</span>
                      {currentTrack?.surahId === item.surahId && isPlaying && (
                        <div className="flex gap-0.5">
                          <span className="w-1 h-3 bg-[var(--color-primary)] rounded animate-pulse"></span>
                          <span className="w-1 h-3 bg-[var(--color-primary)] rounded animate-pulse" style={{ animationDelay: '0.2s' }}></span>
                          <span className="w-1 h-3 bg-[var(--color-primary)] rounded animate-pulse" style={{ animationDelay: '0.4s' }}></span>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function ReciterCard({
  reciter,
  onSelect,
  isFavorite,
  onToggleFavorite,
}: {
  reciter: Reciter;
  onSelect: () => void;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}) {
  return (
    <button
      onClick={onSelect}
      className="w-full bg-[var(--color-bg-elevated)] rounded-2xl p-4 border border-[var(--color-border)] card-hover flex items-center gap-3 text-right"
    >
      <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-primary-dark)] flex items-center justify-center text-white text-2xl shadow-lg">
        🎙️
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-bold mb-0.5">{reciter.arabicName}</p>
        <p className="text-xs text-[var(--color-text-muted)]">{reciter.rewaya}</p>
        {reciter.style && <p className="text-xs text-[var(--color-accent)]">{reciter.style}</p>}
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={(e) => { e.stopPropagation(); onToggleFavorite(); }}
          className={`p-2 rounded-full hover:bg-[var(--color-surface)] ${isFavorite ? 'text-rose-500' : 'text-[var(--color-text-subtle)]'}`}
        >
          <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
        </button>
        <ChevronLeft className="w-5 h-5 text-[var(--color-text-subtle)] rotate-180" />
      </div>
    </button>
  );
}
