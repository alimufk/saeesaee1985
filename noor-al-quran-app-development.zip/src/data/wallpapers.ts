export interface Wallpaper {
  id: string;
  title: string;
  titleAr: string;
  category: string;
  categoryAr: string;
  image: string;
  thumbnail: string;
  resolution: 'HD' | 'Full HD' | '2K' | '4K';
  downloads: number;
  createdAt: string;
  tags: string[];
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
  count: number;
}

// روابط Unsplash مباشرة للصور الإسلامية
const UNSPLASH = 'https://images.unsplash.com';

export const wallpapers: Wallpaper[] = [
  // خلفيات الكعبة المشرفة
  {
    id: 'kaaba-1',
    title: 'Kaaba at Night',
    titleAr: 'الكعبة المشرفة ليلاً',
    category: 'kaaba',
    categoryAr: 'الكعبة المشرفة',
    image: `${UNSPLASH}/photo-1591604129939-f1efa4d9f7fa?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1591604129939-f1efa4d9f7fa?w=400&q=80`,
    resolution: '4K',
    downloads: 15420,
    createdAt: '2025-01-15',
    tags: ['كعبة', 'مكة', 'حرم', 'ليل'],
  },
  {
    id: 'kaaba-2',
    title: 'Kaaba Crowd',
    titleAr: 'الطواف حول الكعبة',
    category: 'kaaba',
    categoryAr: 'الكعبة المشرفة',
    image: `${UNSPLASH}/photo-1565552645632-d725f8bfc19a?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1565552645632-d725f8bfc19a?w=400&q=80`,
    resolution: '4K',
    downloads: 12300,
    createdAt: '2025-01-10',
    tags: ['كعبة', 'طواف', 'حجاج'],
  },
  {
    id: 'kaaba-3',
    title: 'Kaaba Golden',
    titleAr: 'الكعبة بإضاءة ذهبية',
    category: 'kaaba',
    categoryAr: 'الكعبة المشرفة',
    image: `${UNSPLASH}/photo-1542816417-0983c9c9ad53?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1542816417-0983c9c9ad53?w=400&q=80`,
    resolution: '4K',
    downloads: 9876,
    createdAt: '2025-01-05',
    tags: ['كعبة', 'ذهبي', 'مكة'],
  },
  {
    id: 'kaaba-4',
    title: 'Kaaba Aerial',
    titleAr: 'الكعبة من الجو',
    category: 'kaaba',
    categoryAr: 'الكعبة المشرفة',
    image: `${UNSPLASH}/photo-1519817914152-22d216bb9170?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1519817914152-22d216bb9170?w=400&q=80`,
    resolution: '4K',
    downloads: 8543,
    createdAt: '2024-12-28',
    tags: ['كعبة', 'جوي', 'مكة'],
  },

  // خلفيات المسجد النبوي
  {
    id: 'medina-1',
    title: 'Prophet Mosque',
    titleAr: 'المسجد النبوي ليلاً',
    category: 'medina',
    categoryAr: 'المسجد النبوي',
    image: `${UNSPLASH}/photo-1591604466107-ec97de577aff?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1591604466107-ec97de577aff?w=400&q=80`,
    resolution: '4K',
    downloads: 13200,
    createdAt: '2025-01-12',
    tags: ['مدينة', 'مسجد', 'نبوي'],
  },
  {
    id: 'medina-2',
    title: 'Green Dome',
    titleAr: 'القبة الخضراء',
    category: 'medina',
    categoryAr: 'المسجد النبوي',
    image: `${UNSPLASH}/photo-1519817650390-64a93db51149?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1519817650390-64a93db51149?w=400&q=80`,
    resolution: '4K',
    downloads: 10543,
    createdAt: '2025-01-08',
    tags: ['قبة', 'خضراء', 'مدينة'],
  },
  {
    id: 'medina-3',
    title: 'Medina Umbrellas',
    titleAr: 'المظلات في المسجد النبوي',
    category: 'medina',
    categoryAr: 'المسجد النبوي',
    image: `${UNSPLASH}/photo-1564769625392-651b2c1e8a3d?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1564769625392-651b2c1e8a3d?w=400&q=80`,
    resolution: '4K',
    downloads: 8921,
    createdAt: '2024-12-25',
    tags: ['مظلات', 'مسجد', 'نبوي'],
  },

  // خلفيات القرآن الكريم
  {
    id: 'quran-1',
    title: 'Holy Quran',
    titleAr: 'المصحف الشريف',
    category: 'quran',
    categoryAr: 'القرآن الكريم',
    image: `${UNSPLASH}/photo-1585036156261-1ecf2a2f0f13?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1585036156261-1ecf2a2f0f13?w=400&q=80`,
    resolution: '4K',
    downloads: 18765,
    createdAt: '2025-01-18',
    tags: ['قرآن', 'مصحف', 'كريم'],
  },
  {
    id: 'quran-2',
    title: 'Quran with Tasbih',
    titleAr: 'القرآن والسبحة',
    category: 'quran',
    categoryAr: 'القرآن الكريم',
    image: `${UNSPLASH}/photo-1609599006362-8c2c7f8c2f4a?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1609599006362-8c2c7f8c2f4a?w=400&q=80`,
    resolution: 'Full HD',
    downloads: 14321,
    createdAt: '2025-01-14',
    tags: ['قرآن', 'سبحة', 'تسبيح'],
  },
  {
    id: 'quran-3',
    title: 'Quran Open',
    titleAr: 'المصحف المفتوح',
    category: 'quran',
    categoryAr: 'القرآن الكريم',
    image: `${UNSPLASH}/photo-1542816417-0983c9c9ad53?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1542816417-0983c9c9ad53?w=400&q=80`,
    resolution: '4K',
    downloads: 11234,
    createdAt: '2025-01-06',
    tags: ['قرآن', 'مفتوح', 'آيات'],
  },

  // خلفيات العتبات المقدسة
  {
    id: 'imam-ali',
    title: 'Imam Ali Shrine',
    titleAr: 'مرقد الإمام علي (ع)',
    category: 'shrines',
    categoryAr: 'العتبات المقدسة',
    image: `${UNSPLASH}/photo-1584551246679-0daf32f82c9f?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1584551246679-0daf32f82c9f?w=400&q=80`,
    resolution: '4K',
    downloads: 9876,
    createdAt: '2025-01-11',
    tags: ['نجف', 'إمام', 'علي'],
  },
  {
    id: 'imam-hussein',
    title: 'Imam Hussein Shrine',
    titleAr: 'مرقد الإمام الحسين (ع)',
    category: 'shrines',
    categoryAr: 'العتبات المقدسة',
    image: `${UNSPLASH}/photo-1580674285054-bed31e145f59?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1580674285054-bed31e145f59?w=400&q=80`,
    resolution: '4K',
    downloads: 15678,
    createdAt: '2025-01-13',
    tags: ['كربلاء', 'حسين', 'عتبة'],
  },
  {
    id: 'abbas-shrine',
    title: 'Abbas Shrine',
    titleAr: 'مرقد أبي الفضل العباس (ع)',
    category: 'shrines',
    categoryAr: 'العتبات المقدسة',
    image: `${UNSPLASH}/photo-1585036156171-38b52cf6b3b5?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1585036156171-38b52cf6b3b5?w=400&q=80`,
    resolution: '4K',
    downloads: 12345,
    createdAt: '2025-01-09',
    tags: ['كربلاء', 'عباس', 'قمر'],
  },
  {
    id: 'kazimayn',
    title: 'Kazimayn Shrine',
    titleAr: 'العتبة الكاظمية',
    category: 'shrines',
    categoryAr: 'العتبات المقدسة',
    image: `${UNSPLASH}/photo-1580418827493-f2b22c0a76cb?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1580418827493-f2b22c0a76cb?w=400&q=80`,
    resolution: '4K',
    downloads: 8765,
    createdAt: '2025-01-07',
    tags: ['كاظمية', 'بغداد', 'عتبة'],
  },

  // خلفيات شهر رمضان
  {
    id: 'ramadan-1',
    title: 'Ramadan Lantern',
    titleAr: 'فانوس رمضان',
    category: 'ramadan',
    categoryAr: 'شهر رمضان',
    image: `${UNSPLASH}/photo-1581875592167-1da14da5d5f7?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1581875592167-1da14da5d5f7?w=400&q=80`,
    resolution: '4K',
    downloads: 22345,
    createdAt: '2025-01-16',
    tags: ['رمضان', 'فانوس', 'إفطار'],
  },
  {
    id: 'ramadan-2',
    title: 'Ramadan Crescent',
    titleAr: 'هلال رمضان',
    category: 'ramadan',
    categoryAr: 'شهر رمضان',
    image: `${UNSPLASH}/photo-1583468982228-19f19164aee2?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1583468982228-19f19164aee2?w=400&q=80`,
    resolution: '4K',
    downloads: 19876,
    createdAt: '2025-01-15',
    tags: ['هلال', 'رمضان', 'قمر'],
  },
  {
    id: 'ramadan-3',
    title: 'Ramadan Iftar',
    titleAr: 'مائدة الإفطار',
    category: 'ramadan',
    categoryAr: 'شهر رمضان',
    image: `${UNSPLASH}/photo-1585036156171-38b52cf6b3b5?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1585036156171-38b52cf6b3b5?w=400&q=80`,
    resolution: '4K',
    downloads: 15432,
    createdAt: '2025-01-14',
    tags: ['إفطار', 'رمضان', 'طعام'],
  },
  {
    id: 'ramadan-4',
    title: 'Mosque Ramadan',
    titleAr: 'مسجد في رمضان',
    category: 'ramadan',
    categoryAr: 'شهر رمضان',
    image: `${UNSPLASH}/photo-1542816417-0983c9c9ad53?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1542816417-0983c9c9ad53?w=400&q=80`,
    resolution: '4K',
    downloads: 13456,
    createdAt: '2025-01-12',
    tags: ['مسجد', 'رمضان', 'صلاة'],
  },

  // خلفيات الأدعية والأذكار
  {
    id: 'dua-1',
    title: 'Praying Hands',
    titleAr: 'يدان في الدعاء',
    category: 'dua',
    categoryAr: 'الأدعية والأذكار',
    image: `${UNSPLASH}/photo-1542816417-0983c9c9ad53?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1542816417-0983c9c9ad53?w=400&q=80`,
    resolution: 'Full HD',
    downloads: 17890,
    createdAt: '2025-01-17',
    tags: ['دعاء', 'صلاة', 'يدين'],
  },
  {
    id: 'dua-2',
    title: 'Tasbih',
    titleAr: 'السبحة والتسبيح',
    category: 'dua',
    categoryAr: 'الأدعية والأذكار',
    image: `${UNSPLASH}/photo-1590076215667-875d4ef2d7de?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1590076215667-875d4ef2d7de?w=400&q=80`,
    resolution: 'Full HD',
    downloads: 12345,
    createdAt: '2025-01-13',
    tags: ['سبحة', 'تسبيح', 'ذكر'],
  },
  {
    id: 'dua-3',
    title: 'Sujood',
    titleAr: 'السجود',
    category: 'dua',
    categoryAr: 'الأدعية والأذكار',
    image: `${UNSPLASH}/photo-1585036156261-1ecf2a2f0f13?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1585036156261-1ecf2a2f0f13?w=400&q=80`,
    resolution: '4K',
    downloads: 14567,
    createdAt: '2025-01-10',
    tags: ['سجود', 'صلاة', 'خشوع'],
  },

  // خلفيات المناسبات الدينية
  {
    id: 'eid-1',
    title: 'Eid Mubarak',
    titleAr: 'عيد مبارك',
    category: 'occasions',
    categoryAr: 'المناسبات الدينية',
    image: `${UNSPLASH}/photo-1583468982228-19f19164aee2?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1583468982228-19f19164aee2?w=400&q=80`,
    resolution: '4K',
    downloads: 25678,
    createdAt: '2025-01-19',
    tags: ['عيد', 'مبارك', 'فرح'],
  },
  {
    id: 'eid-2',
    title: 'Eid Al-Adha',
    titleAr: 'عيد الأضحى',
    category: 'occasions',
    categoryAr: 'المناسبات الدينية',
    image: `${UNSPLASH}/photo-1581875592167-1da14da5d5f7?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1581875592167-1da14da5d5f7?w=400&q=80`,
    resolution: '4K',
    downloads: 18765,
    createdAt: '2025-01-18',
    tags: ['عيد', 'أضحى', 'حج'],
  },
  {
    id: 'eid-3',
    title: 'Eid Al-Fitr',
    titleAr: 'عيد الفطر',
    category: 'occasions',
    categoryAr: 'المناسبات الدينية',
    image: `${UNSPLASH}/photo-1583468982228-19f19164aee2?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1583468982228-19f19164aee2?w=400&q=80`,
    resolution: '4K',
    downloads: 22345,
    createdAt: '2025-01-17',
    tags: ['عيد', 'فطر', 'رمضان'],
  },

  // خلفيات ثلاثية الأبعاد
  {
    id: '3d-1',
    title: 'Islamic 3D Art',
    titleAr: 'فن إسلامي ثلاثي الأبعاد',
    category: '3d',
    categoryAr: 'خلفيات ثلاثية الأبعاد',
    image: `${UNSPLASH}/photo-1585036156171-38b52cf6b3b5?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1585036156171-38b52cf6b3b5?w=400&q=80`,
    resolution: '4K',
    downloads: 16789,
    createdAt: '2025-01-16',
    tags: ['فن', '3d', 'هندسة'],
  },
  {
    id: '3d-2',
    title: 'Arabic Calligraphy 3D',
    titleAr: 'خط عربي ثلاثي الأبعاد',
    category: '3d',
    categoryAr: 'خلفيات ثلاثية الأبعاد',
    image: `${UNSPLASH}/photo-1542816417-0983c9c9ad53?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1542816417-0983c9c9ad53?w=400&q=80`,
    resolution: '4K',
    downloads: 14567,
    createdAt: '2025-01-14',
    tags: ['خط', 'عربي', '3d'],
  },
  {
    id: '3d-3',
    title: 'Mosque 3D',
    titleAr: 'مسجد ثلاثي الأبعاد',
    category: '3d',
    categoryAr: 'خلفيات ثلاثية الأبعاد',
    image: `${UNSPLASH}/photo-1519817914152-22d216bb9170?w=1920&q=90`,
    thumbnail: `${UNSPLASH}/photo-1519817914152-22d216bb9170?w=400&q=80`,
    resolution: '4K',
    downloads: 12345,
    createdAt: '2025-01-12',
    tags: ['مسجد', '3d', 'هندسة'],
  },
];

export const categories: Category[] = [
  {
    id: 'all',
    name: 'الكل',
    icon: 'Grid3x3',
    color: 'from-slate-500 to-slate-700',
    count: wallpapers.length,
  },
  {
    id: 'kaaba',
    name: 'الكعبة المشرفة',
    icon: 'Kaaba',
    color: 'from-amber-600 to-yellow-700',
    count: wallpapers.filter(w => w.category === 'kaaba').length,
  },
  {
    id: 'medina',
    name: 'المسجد النبوي',
    icon: 'Landmark',
    color: 'from-emerald-500 to-green-700',
    count: wallpapers.filter(w => w.category === 'medina').length,
  },
  {
    id: 'quran',
    name: 'القرآن الكريم',
    icon: 'BookOpen',
    color: 'from-teal-500 to-cyan-700',
    count: wallpapers.filter(w => w.category === 'quran').length,
  },
  {
    id: 'shrines',
    name: 'العتبات المقدسة',
    icon: 'Star',
    color: 'from-purple-500 to-violet-700',
    count: wallpapers.filter(w => w.category === 'shrines').length,
  },
  {
    id: 'ramadan',
    name: 'شهر رمضان',
    icon: 'Moon',
    color: 'from-indigo-500 to-purple-700',
    count: wallpapers.filter(w => w.category === 'ramadan').length,
  },
  {
    id: 'dua',
    name: 'الأدعية والأذكار',
    icon: 'Heart',
    color: 'from-rose-500 to-pink-700',
    count: wallpapers.filter(w => w.category === 'dua').length,
  },
  {
    id: 'occasions',
    name: 'المناسبات الدينية',
    icon: 'Calendar',
    color: 'from-red-500 to-rose-700',
    count: wallpapers.filter(w => w.category === 'occasions').length,
  },
  {
    id: '3d',
    name: 'خلفيات ثلاثية الأبعاد',
    icon: 'Box',
    color: 'from-cyan-500 to-blue-700',
    count: wallpapers.filter(w => w.category === '3d').length,
  },
];

// دالة لتحميل الصور حسب الفئة
export const getWallpapersByCategory = (categoryId: string): Wallpaper[] => {
  if (categoryId === 'all') return wallpapers;
  return wallpapers.filter(w => w.category === categoryId);
};

// دالة للبحث
export const searchWallpapers = (query: string): Wallpaper[] => {
  const q = query.toLowerCase();
  return wallpapers.filter(w => 
    w.titleAr.includes(q) ||
    w.title.toLowerCase().includes(q) ||
    w.categoryAr.includes(q) ||
    w.tags.some(t => t.includes(q))
  );
};

// دالة للترتيب حسب الأكثر تحميلاً
export const getMostDownloaded = (): Wallpaper[] => {
  return [...wallpapers].sort((a, b) => b.downloads - a.downloads);
};

// دالة للترتيب حسب الأحدث
export const getNewest = (): Wallpaper[] => {
  return [...wallpapers].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
};
