export interface Book {
  id: string;
  title: string;
  author: string;
  description: string;
  chapters: { title: string; content: string }[];
}

export const books: Book[] = [
  {
    id: 'nahj',
    title: 'نهج البلاغة',
    author: 'الإمام علي بن أبي طالب (ع)',
    description: 'كتاب جامع لخطب ورسائل وحكم الإمام علي (ع) الذي جمعه الشريف الرضي',
    chapters: [
      {
        title: 'الخطبة الأولى - في بدء الخلق',
        content: 'الْحَمْدُ لِلَّهِ الَّذِي لَا يَبْلُغُ مِدْحَتَهُ الْقَائِلُونَ، وَلَا يُحْصِي نَعْمَاءَهُ الْعَادُّونَ، وَلَا يُؤَدِّي حَقَّهُ الْمُجْتَهِدُونَ...',
      },
      {
        title: 'حكمة: في المعرفة',
        content: 'أَوَّلُ الدِّينِ مَعْرِفَتُهُ، وَكَمَالُ مَعْرِفَتِهِ التَّصْدِيقُ بِهِ، وَكَمَالُ التَّصْدِيقِ بِهِ تَوْحِيدُهُ...',
      },
    ],
  },
  {
    id: 'sahifa',
    title: 'الصحيفة السجادية',
    author: 'الإمام زين العابدين (ع)',
    description: 'أخت الإنجيل وزبور آل محمد، تحوي 54 دعاء',
    chapters: [
      {
        title: 'الدعاء الأول - حمد الله',
        content: 'الْحَمْدُ لِلَّهِ الَّذِي لَا مُعَاقِبَةَ لَهُ، وَالْحَمْدُ لِلَّهِ الَّذِي لَا مَطْعَنَ فِي حُكْمِهِ...',
      },
    ],
  },
  {
    id: 'mafateeh',
    title: 'مفاتيح الجنان',
    author: 'الشيخ عباس القمي',
    description: 'كتاب جامع للأدعية والزيارات والأعمال المستحبة',
    chapters: [
      {
        title: 'أعمال يوم الجمعة',
        content: 'اعلم أن يوم الجمعة سيد الأيام، وفيه من الأعمال والزيارات ما لا يسع المقام ذكره...',
      },
    ],
  },
  {
    id: 'prophets',
    title: 'قصص الأنبياء',
    author: 'من القرآن الكريم',
    description: 'قصص الأنبياء والمرسلين كما وردت في القرآن الكريم',
    chapters: [
      {
        title: 'قصة آدم عليه السلام',
        content: 'خلق الله آدم بيده ونفخ فيه من روحه وأسجد له الملائكة، فعصى بإبليس فأُهبط إلى الأرض...',
      },
      {
        title: 'قصة إبراهيم عليه السلام',
        content: 'خليل الله، الذي حطّم الأصنام وألقي في النار فكانت برداً وسلاماً عليه...',
      },
    ],
  },
  {
    id: 'seerah',
    title: 'سيرة أهل البيت (ع)',
    author: 'مؤلفون متعددون',
    description: 'سيرة النبي محمد (ص) وأهل بيته الأطهار',
    chapters: [
      {
        title: 'مولد النبي الأعظم (ص)',
        content: 'ولد النبي محمد (ص) في عام الفيل في مكة المكرمة، يوم الجمعة 17 ربيع الأول...',
      },
      {
        title: 'سيدة نساء العالمين',
        content: 'فاطمة الزهراء (ع) بنت رسول الله (ص) سيدة نساء العالمين...',
      },
    ],
  },
];

export interface Occasion {
  id: string;
  title: string;
  hijriDate: string;
  gregorianDate: string;
  description: string;
  type: 'happy' | 'mourning' | 'worship';
}

export const occasions: Occasion[] = [
  {
    id: 'o1',
    title: 'رأس السنة الهجرية',
    hijriDate: '1 محرم',
    gregorianDate: 'تختلف كل عام',
    description: 'بداية السنة الهجرية الجديدة، ذكرى هجرة النبي (ص) إلى المدينة',
    type: 'worship',
  },
  {
    id: 'o2',
    title: 'عاشوراء',
    hijriDate: '10 محرم',
    gregorianDate: 'تختلف كل عام',
    description: 'يوم استشهاد الإمام الحسين (ع) في كربلاء',
    type: 'mourning',
  },
  {
    id: 'o3',
    title: 'المولد النبوي الشريف',
    hijriDate: '17 ربيع الأول',
    gregorianDate: 'تختلف كل عام',
    description: 'ولادة خاتم الأنبياء محمد (ص)',
    type: 'happy',
  },
  {
    id: 'o4',
    title: 'ليلة القدر',
    hijriDate: '23 رمضان',
    gregorianDate: 'تختلف كل عام',
    description: 'خير من ألف شهر، فيها تُنزل الملائكة والروح',
    type: 'worship',
  },
  {
    id: 'o5',
    title: 'عيد الفطر',
    hijriDate: '1 شوال',
    gregorianDate: 'تختلف كل عام',
    description: 'عيد انتهاء شهر رمضان المبارك',
    type: 'happy',
  },
  {
    id: 'o6',
    title: 'عيد الأضحى',
    hijriDate: '10 ذو الحجة',
    gregorianDate: 'تختلف كل عام',
    description: 'يوم النحر والحج الأكبر',
    type: 'happy',
  },
  {
    id: 'o7',
    title: 'عيد الغدير',
    hijriDate: '18 ذو الحجة',
    gregorianDate: 'تختلف كل عام',
    description: 'يوم إكمال الدين وإتمام النعمة بتولية أمير المؤمنين (ع)',
    type: 'happy',
  },
];

export const dailyVerse = {
  surah: 'البقرة',
  ayah: 286,
  text: 'لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا',
};

export const dailyHadith = {
  text: 'إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى',
  narrator: 'عن رسول الله (ص)',
};
