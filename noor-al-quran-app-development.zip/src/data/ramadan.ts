export interface RamadanDay {
  day: number;
  suhoor: string;
  iftar: string;
  dua: string;
  virtue?: string;
}

export interface RamadanDua {
  id: string;
  title: string;
  text: string;
  when: string;
  virtue?: string;
}

export interface RamadanTip {
  id: string;
  title: string;
  description: string;
  category: 'worship' | 'health' | 'food' | 'spiritual';
}

// بيانات رمضان - يمكن تحديثها سنوياً
export const ramadanInfo = {
  year: 1447,
  gregorianYear: 2026,
  startDate: '2026-02-18',
  endDate: '2026-03-19',
  days: 30,
};

// أوقات الإمساك والإفطار (بيانات تجريبية - يمكن ربطها بـ API حقيقي)
export const ramadanDays: RamadanDay[] = Array.from({ length: 30 }, (_, i) => ({
  day: i + 1,
  suhoor: '04:45',
  iftar: '18:15',
  dua: `دعاء اليوم ${i + 1}`,
  virtue: i === 0 ? 'أول يوم من رمضان - ليلة مباركة' : 
          i === 26 ? 'ليلة القدر - خير من ألف شهر' :
          i === 29 ? 'آخر يوم من رمضان' : undefined,
}));

// أدعية رمضان
export const ramadanDuas: RamadanDua[] = [
  {
    id: 'iftar',
    title: 'دعاء الإفطار',
    text: 'اللَّهُمَّ لَكَ صُمْتُ وَعَلَى رِزْقِكَ أَفْطَرْتُ، ذَهَبَ الظَّمَأُ وَابْتَلَّتِ الْعُرُوقُ وَثَبَتَ الْأَجْرُ إِنْ شَاءَ اللَّهُ',
    when: 'عند الإفطار',
    virtue: 'يُقال عند الإفطار',
  },
  {
    id: 'suhoor',
    title: 'نية الصيام',
    text: 'نَوَيْتُ صَوْمَ غَدٍ مِنْ شَهْرِ رَمَضَانَ إِيمَانًا وَاحْتِسَابًا لِلَّهِ تَعَالَى',
    when: 'عند السحور',
    virtue: 'نية الصيام',
  },
  {
    id: 'qadr',
    title: 'دعاء ليلة القدر',
    text: 'اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي',
    when: 'ليلة القدر',
    virtue: 'من قالها موقناً بها غُفر له',
  },
  {
    id: 'fasting',
    title: 'دعاء الصائم',
    text: 'اللَّهُمَّ إِنِّي أَسْأَلُكَ بِرَحْمَتِكَ الَّتِي وَسِعَتْ كُلَّ شَيْءٍ أَنْ تَغْفِرَ لِي',
    when: 'في نهار رمضان',
    virtue: 'دعاء مستجاب للصائم',
  },
  {
    id: 'taraweeh',
    title: 'دعاء التراويح',
    text: 'اللَّهُمَّ تَقَبَّلْ مِنَّا إِنَّكَ أَنتَ السَّمِيعُ الْعَلِيمُ وَتُبْ عَلَيْنَا إِنَّكَ أَنتَ التَّوَّابُ الرَّحِيمُ',
    when: 'بعد صلاة التراويح',
    virtue: 'دعاء ختم الصلاة',
  },
  {
    id: 'laylatul_qadr_1',
    title: 'دعاء العشر الأواخر',
    text: 'اللَّهُمَّ إِنَّكَ عَفُوٌّ كَرِيمٌ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي',
    when: 'العشر الأواخر',
    virtue: 'يُستحب في العشر الأواخر',
  },
];

// نصائح للصائمين
export const ramadanTips: RamadanTip[] = [
  {
    id: 'tip1',
    title: 'السحور بركة',
    description: 'تناول السحور ولو بشربة ماء، فهو بركة ويزيد من نشاطك خلال النهار',
    category: 'food',
  },
  {
    id: 'tip2',
    title: 'الإكثار من قراءة القرآن',
    description: 'اجعل لك ورداً يومياً من القرآن، وحاول ختمه في رمضان',
    category: 'worship',
  },
  {
    id: 'tip3',
    title: 'الاعتدال في الطعام',
    description: 'لا تفرط في الطعام عند الإفطار، وابدأ بالتمر والماء',
    category: 'health',
  },
  {
    id: 'tip4',
    title: 'صلاة التراويح',
    description: 'حافظ على صلاة التراويح كاملة، فهي قيام الليل في رمضان',
    category: 'worship',
  },
  {
    id: 'tip5',
    title: 'الصدقة والإحسان',
    description: 'أكثر من الصدقة في رمضان، فالصدقة في رمضان لها أجر عظيم',
    category: 'spiritual',
  },
  {
    id: 'tip6',
    title: 'الدعاء عند الإفطار',
    description: 'للصائم عند فطره دعوة لا تُرد، فاغتنم هذه اللحظة',
    category: 'spiritual',
  },
  {
    id: 'tip7',
    title: 'شرب الماء',
    description: 'اشرب كمية كافية من الماء بين الإفطار والسحور لتجنب الجفاف',
    category: 'health',
  },
  {
    id: 'tip8',
    title: 'العمرة في رمضان',
    description: 'العمرة في رمضان تعدل حجة مع النبي (ص) لمن استطاع',
    category: 'worship',
  },
  {
    id: 'tip9',
    title: 'صلة الرحم',
    description: 'احرص على صلة الرحم وزيارة الأقارب في رمضان',
    category: 'spiritual',
  },
  {
    id: 'tip10',
    title: 'الاعتكاف',
    description: 'اعتكف في العشر الأواخر من رمضان لطلب ليلة القدر',
    category: 'worship',
  },
];

// أعمال العشر الأواخر
export const lastTenDays = [
  {
    day: 21,
    title: 'أول ليلة من العشر الأواخر',
    actions: ['الاجتهاد في العبادة', 'الاعتكاف', 'طلب ليلة القدر'],
  },
  {
    day: 23,
    title: 'ليلة القدر (محتملة)',
    actions: ['الإكثار من الدعاء', 'قراءة القرآن', 'الاستغفار'],
  },
  {
    day: 25,
    title: 'ليلة القدر (محتملة)',
    actions: ['قيام الليل', 'الدعاء المأثور', 'التوبة والاستغفار'],
  },
  {
    day: 27,
    title: 'ليلة القدر (مرجحة)',
    actions: ['الإكثار من العبادة', 'دعاء ليلة القدر', 'الصدقة'],
  },
  {
    day: 29,
    title: 'آخر ليلة من رمضان',
    actions: ['وداع الشهر', 'الدعاء بالقبول', 'زكاة الفطر'],
  },
];

// فضائل رمضان
export const ramadanVirtues = [
  {
    title: 'شهر الصيام',
    description: 'فُرض صيام رمضان في السنة الثانية من الهجرة',
    icon: '🌙',
  },
  {
    title: 'شهر القرآن',
    description: 'أُنزل فيه القرآن هدى للناس وبينات من الهدى والفرقان',
    icon: '📖',
  },
  {
    title: 'ليلة القدر',
    description: 'فيه ليلة القدر خير من ألف شهر',
    icon: '✨',
  },
  {
    title: 'شهر الرحمة',
    description: 'أوله رحمة وأوسطه مغفرة وآخره عتق من النار',
    icon: '❤️',
  },
  {
    title: 'شهر الجود',
    description: 'كان النبي (ص) أجود ما يكون في رمضان',
    icon: '🤲',
  },
  {
    title: 'شهر الانتصار',
    description: 'فيه انتصارات المسلمين: بدر، الفتح، عين جالوت',
    icon: '⚔️',
  },
];

// حاسبة زكاة الفطر
export const zakatAlFitr = {
  amount: 3, // صاع
  kg: 2.5, // تقريباً 2.5 كجم
  types: ['تمر', 'زبيب', 'أقط', 'بر', 'شعير', 'أرز'],
  perPerson: 'صاع من غالب قوت البلد',
};

// أهداف ختم القرآن
export const quranKhatmGoals = [
  { days: 30, juzPerDay: 1, pagesPerDay: 20, description: 'ختم واحد في رمضان' },
  { days: 15, juzPerDay: 2, pagesPerDay: 40, description: 'ختمتان في رمضان' },
  { days: 10, juzPerDay: 3, pagesPerDay: 60, description: 'ثلاث ختمات في رمضان' },
];
