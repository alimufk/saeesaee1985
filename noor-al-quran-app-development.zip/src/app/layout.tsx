import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'نور القرآن - تطبيق إسلامي شامل',
  description: 'تطبيق إسلامي احترافي: القرآن الكريم، الأذكار، الأدعية، مواقيت الصلاة، التسبيح، البث المباشر، ومساعد إسلامي ذكي',
  manifest: '/manifest.json',
  icons: { icon: '/icon.svg' },
};

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#0d6b4e' },
    { media: '(prefers-color-scheme: dark)', color: '#0d1412' },
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body className="min-h-screen islamic-pattern">{children}</body>
    </html>
  );
}
