'use client';

import { useState, useEffect } from 'react';
import {
  Home, BookOpen, Sparkles, Heart, Clock, Beaker, Calendar, Library, Radio,
  Brain, Sun, Moon, Menu, X, ChevronLeft, Mic, MapPin, Image as ImageIcon,
  Navigation, Moon as MoonIcon,
} from 'lucide-react';
import HomePage from '@/components/HomePage';
import QuranPage from '@/components/QuranPage';
import AzkarPage from '@/components/AzkarPage';
import DuasPage from '@/components/DuasPage';
import PrayerTimesPage from '@/components/PrayerTimesPage';
import TasbihPage from '@/components/TasbihPage';
import OccasionsPage from '@/components/OccasionsPage';
import LibraryPage from '@/components/LibraryPage';
import LiveStreamPage from '@/components/LiveStreamPage';
import AssistantPage from '@/components/AssistantPage';
import RecitersPage from '@/components/RecitersPage';
import ZiyaratPage from '@/components/ZiyaratPage';
import WallpapersPage from '@/components/WallpapersPage';
import NearbyMosquesPage from '@/components/NearbyMosquesPage';
import RamadanPage from '@/components/RamadanPage';

type Section = 'home' | 'quran' | 'reciters' | 'azkar' | 'duas' | 'prayer' | 'tasbih' | 'ziyarat' | 'occasions' | 'library' | 'live' | 'assistant' | 'wallpapers' | 'mosques' | 'ramadan';

const navItems: { id: Section; label: string; icon: any }[] = [
  { id: 'home', label: 'الرئيسية', icon: Home },
  { id: 'quran', label: 'القرآن', icon: BookOpen },
  { id: 'reciters', label: 'التلاوة', icon: Mic },
  { id: 'azkar', label: 'الأذكار', icon: Sparkles },
  { id: 'duas', label: 'الأدعية', icon: Heart },
  { id: 'prayer', label: 'الصلاة', icon: Clock },
  { id: 'mosques', label: 'المساجد', icon: Navigation },
  { id: 'tasbih', label: 'التسبيح', icon: Beaker },
  { id: 'ziyarat', label: 'الزيارات', icon: MapPin },
  { id: 'occasions', label: 'المناسبات', icon: Calendar },
  { id: 'library', label: 'المكتبة', icon: Library },
  { id: 'wallpapers', label: 'الخلفيات', icon: ImageIcon },
  { id: 'ramadan', label: 'رمضان', icon: MoonIcon },
  { id: 'live', label: 'البث', icon: Radio },
  { id: 'assistant', label: 'المساعد', icon: Brain },
];

export default function AppShell() {
  const [section, setSection] = useState<Section>('home');
  const [dark, setDark] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const saved = typeof window !== 'undefined' ? localStorage.getItem('noor-theme') : null;
    const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
    const isDark = saved ? saved === 'dark' : prefersDark ?? true;
    setDark(isDark);
    document.documentElement.classList.toggle('dark', isDark);
  }, []);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle('dark', next);
    if (typeof window !== 'undefined') localStorage.setItem('noor-theme', next ? 'dark' : 'light');
  };

  const navigate = (id: Section) => {
    setSection(id);
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!mounted) {
    return <div className="min-h-screen flex items-center justify-center"><div className="text-[var(--color-text-muted)]">جارٍ التحميل...</div></div>;
  }

  const currentNav = navItems.find((n) => n.id === section);

  return (
    <div className="min-h-screen flex flex-col max-w-[480px] mx-auto bg-[var(--color-bg)] shadow-2xl relative overflow-hidden">
      {/* Header */}
      <header className="sticky top-0 z-40 glass border-b border-[var(--color-border)]">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            {section !== 'home' && (
              <button onClick={() => setSection('home')} className="p-2 rounded-full hover:bg-[var(--color-surface)] transition-colors" aria-label="رجوع">
                <ChevronLeft className="w-5 h-5 rotate-180" />
              </button>
            )}
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl prayer-gradient flex items-center justify-center text-white font-bold text-lg">
                ☪
              </div>
              <div>
                <h1 className="font-display text-lg font-bold leading-tight">{section === 'home' ? 'نور القرآن' : currentNav?.label}</h1>
                {section === 'home' && <p className="text-xs text-[var(--color-text-muted)]">تطبيقك الإسلامي الشامل</p>}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button onClick={toggleTheme} className="p-2 rounded-full hover:bg-[var(--color-surface)] transition-colors" aria-label="تبديل الوضع">
              {dark ? <Sun className="w-5 h-5 text-[var(--color-accent)]" /> : <Moon className="w-5 h-5 text-[var(--color-primary)]" />}
            </button>
            <button onClick={() => setMenuOpen(!menuOpen)} className="p-2 rounded-full hover:bg-[var(--color-surface)] transition-colors" aria-label="القائمة">
              {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Drawer */}
      {menuOpen && (
        <div className="fixed inset-0 z-30 bg-black/40 backdrop-blur-sm max-w-[480px] mx-auto" onClick={() => setMenuOpen(false)}>
          <div
            className="absolute top-0 right-0 h-full w-72 bg-[var(--color-bg)] border-l border-[var(--color-border)] p-4 overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 mb-6 pb-4 border-b border-[var(--color-border)]">
              <div className="w-12 h-12 rounded-2xl prayer-gradient flex items-center justify-center text-white text-2xl">☪</div>
              <div>
                <h2 className="font-display font-bold">نور القرآن</h2>
                <p className="text-xs text-[var(--color-text-muted)]">الإصدار 2.0</p>
              </div>
            </div>
            <nav className="space-y-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => navigate(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all ${
                    section === item.id ? 'bg-[var(--color-primary)] text-white' : 'hover:bg-[var(--color-surface)]'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </button>
              ))}
            </nav>
            <div className="mt-6 p-4 rounded-xl bg-[var(--color-surface)] text-center">
              <p className="text-sm text-[var(--color-text-muted)]">اللهم صلّ على محمد وآل محمد</p>
            </div>
          </div>
        </div>
      )}

      {/* Main content */}
      <main className="flex-1 pb-20 overflow-x-hidden">
        <div key={section} className="page-transition">
          {section === 'home' && <HomePage onNavigate={navigate} />}
          {section === 'quran' && <QuranPage />}
          {section === 'reciters' && <RecitersPage />}
          {section === 'azkar' && <AzkarPage />}
          {section === 'duas' && <DuasPage />}
          {section === 'prayer' && <PrayerTimesPage />}
          {section === 'mosques' && <NearbyMosquesPage />}
          {section === 'tasbih' && <TasbihPage />}
          {section === 'ziyarat' && <ZiyaratPage />}
          {section === 'occasions' && <OccasionsPage />}
          {section === 'library' && <LibraryPage />}
          {section === 'wallpapers' && <WallpapersPage />}
          {section === 'ramadan' && <RamadanPage />}
          {section === 'live' && <LiveStreamPage />}
          {section === 'assistant' && <AssistantPage />}
        </div>
      </main>

      {/* Bottom navigation - scrollable */}
      <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] z-30 glass border-t border-[var(--color-border)]">
        <div className="flex overflow-x-auto no-scrollbar px-2 py-2 gap-1">
          {navItems.map((item) => {
            const active = section === item.id;
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`nav-item flex flex-col items-center gap-1 py-1.5 px-2 rounded-xl relative flex-shrink-0 min-w-[56px] ${active ? 'active' : 'text-[var(--color-text-muted)]'}`}
              >
                <item.icon className="w-5 h-5" />
                <span className="text-[10px] font-medium whitespace-nowrap">{item.label}</span>
                {active && <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[var(--color-primary)]" />}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
